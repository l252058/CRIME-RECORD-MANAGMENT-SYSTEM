#ifndef CRIMERECORDS_H
#define CRIMERECORDS_H

#include <QMessageBox>
#include <QTextEdit>

#include "common.h"
#include "file.h"

// =============================================================================
//  Helper : formats one pipe-delimited record line into readable text
// =============================================================================

static QString formatRecord(const QStringList &recordParts)
{
    if (recordParts.size() < 5)
    {
        return "";
    }

    return "Case ID   : " + recordParts[0].trimmed() + "\n"
           "Location  : " + recordParts[1].trimmed() + "\n"
           "Type      : " + recordParts[2].trimmed() + "\n"
           "Desc      : " + recordParts[3].trimmed() + "\n"
           "Status    : " + recordParts[4].trimmed() + "\n"
           "----------------------------------\n";
}


// =============================================================================
//  VIEW PANEL
// =============================================================================

class View : public QWidget
{
private:
    Button *refresh;
    RecordDisplay *display;
    bool isAdminRole;

public:
    View(bool adminRole, QWidget *parent = nullptr) : QWidget(parent), isAdminRole(adminRole)
    {
        QLabel *heading = new QLabel("  ALL CRIME RECORDS", this);
        
        heading->setGeometry(0, 8, 860, 30);
        
        heading->setStyleSheet(
            MONO +
            "font-size   : 18px;"
            "font-weight : bold;"
            "color       : #00eaff;"
            "background  : transparent;"
        );

        refresh = new Button("REFRESH", 1000, 6, 140, 34, this);
        
        display = new RecordDisplay(0, 50, 1150, 625, this, "  Click Refresh to load all records.");

        QObject::connect(refresh, &QPushButton::clicked, [this]()
        {
            QStringList records = FileHandler::loadRecords();

            if (records.isEmpty())
            {
                display->setText("  No records found.");
                return;
            }

            QString outputText;

            for (const QString &line : records)
            {
                outputText += formatRecord(line.split("\t"));
            }

            display->setText(outputText);

            QString role;
            
            if (isAdminRole)
            {
                role = "ADMIN";
            }
            else
            {
                role = "USER";
            }

            FileHandler::appendLog(role, "Viewed all crime records (" + QString::number(records.size()) + " records)");
        });
    }
};

// =============================================================================
//  SEARCH PANEL
// =============================================================================

class Search : public QWidget
{
private:
    Box *caseIDBox;
    Button *searchOne;
    Box *locationBox;
    Button *searchTwo;
    RecordDisplay *searchResult;
    bool isAdminRole;

    void performSearch(int fieldIndex, QLineEdit *inputField)
    {
        QString query = inputField->text().trimmed();

        if (query.isEmpty())
        {
            searchResult->setText("  Enter a search term.");
            return;
        }

        QString outputText;

        for (const QString &line : FileHandler::loadRecords())
        {
            QStringList recordParts = line.split("\t");

            if (recordParts.size() > fieldIndex)
            {
                if (recordParts[fieldIndex].contains(query, Qt::CaseInsensitive))
                {
                    outputText += formatRecord(recordParts);
                }
            }
        }

        if (outputText.isEmpty())
        {
            searchResult->setText("  No matching records found.");
        }
        else
        {
            searchResult->setText(outputText);
        }

        QString role;
        
        if (isAdminRole)
        {
            role = "ADMIN";
        }
        else
        {
            role = "USER";
        }
        
        FileHandler::appendLog(role, "Searched crime records for: " + query);
    }

public:
    Search(bool adminRole, QWidget *parent = nullptr) : QWidget(parent), isAdminRole(adminRole)
    {
        Card *searchCard = new Card(170, 0, 800, 240, this, "SEARCH CRIME RECORDS");

        QLabel *caseIdLabel = new QLabel("Search by Case ID", searchCard);
        caseIdLabel->setGeometry(20, 68, 760, 20);
        caseIdLabel->setStyleSheet(MONO + "font-size:18px; font-weight:bold; color:#a0d8f0; background:transparent;");

        caseIDBox = new Box(20, 100, 570, 38, "e.g.  CR-001", searchCard);
        searchOne = new Button("Search", 600, 100, 180, 38, searchCard);

        QLabel *locationLabel = new QLabel("Search by Location", searchCard);
        locationLabel->setGeometry(20, 155, 760, 20);
        locationLabel->setStyleSheet(MONO + "font-size:18px; font-weight:bold; color:#a0d8f0; background:transparent;");

        locationBox = new Box(20, 180, 570, 38, "e.g.  Karachi", searchCard);
        searchTwo = new Button("Search", 600, 180, 180, 38, searchCard);

        searchResult = new RecordDisplay(0, 280, 1150, 410, this, "  Enter a search term above and press Search.");

        QObject::connect(searchOne, &QPushButton::clicked, [this]()
        {
            performSearch(0, caseIDBox);
        });

        QObject::connect(searchTwo, &QPushButton::clicked, [this]()
        {
            performSearch(1, locationBox);
        });
    }
};

// =============================================================================
//  SORT PANEL
// =============================================================================

class Sort : public QWidget
{
private:
    Button *caseIDSort;
    Button *locationSort;
    Button *statusSort;
    RecordDisplay *sortResult;
    bool isAdminRole;

public:
    Sort(bool adminRole, QWidget *parent = nullptr) : QWidget(parent), isAdminRole(adminRole)
    {
        Card *sortCard = new Card(170, 0, 800, 140, this, "SORT CRIME RECORDS");

        caseIDSort   = new Button("BY CASE ID",  20, 68, 250, 48, sortCard);
        locationSort = new Button("BY LOCATION", 275, 68, 250, 48, sortCard);
        statusSort   = new Button("BY STATUS",   530, 68, 250, 48, sortCard);

        sortResult = new RecordDisplay(0, 150, 1150, 430, this, "  Press a sort button above.");

        auto doSort = [this](int field)
        {
            QStringList rawRecords = FileHandler::loadRecords();
            QList<QStringList> parsedRecords;

            for (const QString &line : rawRecords)
            {
                parsedRecords.append(line.split("\t"));
            }

            pureBubbleSort(parsedRecords, field);

            QString outputText;

            for (const QStringList &recordParts : parsedRecords)
            {
                outputText += formatRecord(recordParts);
            }

            if (outputText.isEmpty())
            {
                sortResult->setText("  No records found.");
            }
            else
            {
                sortResult->setText(outputText);
            }
        };

        QObject::connect(caseIDSort, &QPushButton::clicked, [this, doSort]()
        {
            doSort(0);
            
            QString role;
            
            if (isAdminRole)
            {
                role = "ADMIN";
            }
            else
            {
                role = "USER";
            }
            
            FileHandler::appendLog(role, "Sorted crime records by Case ID");
        });

        QObject::connect(locationSort, &QPushButton::clicked, [this, doSort]()
        {
            doSort(1);
            
            QString role;
            
            if (isAdminRole)
            {
                role = "ADMIN";
            }
            else
            {
                role = "USER";
            }
            
            FileHandler::appendLog(role, "Sorted crime records by Location");
        });

        QObject::connect(statusSort, &QPushButton::clicked, [this, doSort]()
        {
            doSort(4);
            
            QString role;
            
            if (isAdminRole)
            {
                role = "ADMIN";
            }
            else
            {
                role = "USER";
            }
            
            FileHandler::appendLog(role, "Sorted crime records by Status");
        });
    }
};

// =============================================================================
//  MODIFY PANEL
// =============================================================================

class Modify : public QWidget
{
private:
    Box *caseIDBox;
    Box *locationBox;
    Box *typeBox;
    DescriptionBox *descriptionBox;
    Button *loadButton;
    QPushButton *saveButton;
    QPushButton *deleteButton;
    QLabel *message;
    QString selectedStatus;

    void setMessage(const QString &text, const QString &color)
    {
        message->setStyleSheet(
            MONO +
            "font-size  : 16px;"
            "color      : " + color + ";"
            "background : transparent;"
        );
        
        message->setText(text);
    }

public:
    Modify(QWidget *parent = nullptr) : QWidget(parent), selectedStatus("Pending")
    {
        Card *modifyCard = new Card(20, 0, 1140, 680, this, "MODIFY / DELETE RECORD");

        QLabel *instructionLabel = new QLabel("Enter Case ID to load the record", modifyCard);
        instructionLabel->setGeometry(40, 75, 1100, 20);
        instructionLabel->setStyleSheet(MONO + "font-size:16px; color:#a0d8f0; background:transparent;");

        caseIDBox = new Box(40, 100, 900, 38, "e.g.  CR-001", modifyCard);
        loadButton = new Button("  Load Record", 960, 100, 160, 38, modifyCard);

        QLabel *editInstructionLabel = new QLabel("Edit the fields below then Save or Delete", modifyCard);
        editInstructionLabel->setGeometry(40, 155, 1100, 20);
        editInstructionLabel->setStyleSheet(MONO + "font-size:16px; color:#a0d8f0; background:transparent;");

        QLabel *locationLabel = new QLabel(" Location  *", modifyCard);
        locationLabel->setGeometry(40, 190, 300, 24);
        locationLabel->setStyleSheet(MONO + "font-size:20px; font-weight:bold; color:#00eaff; background:transparent;");

        locationBox = new Box(40, 220, 1080, 38, " ", modifyCard);

        QLabel *crimeTypeLabel = new QLabel(" Crime Type  *", modifyCard);
        crimeTypeLabel->setGeometry(40, 275, 300, 24);
        crimeTypeLabel->setStyleSheet(MONO + "font-size:20px; font-weight:bold; color:#00eaff; background:transparent;");

        typeBox = new Box(40, 305, 1080, 38, " ", modifyCard);

        QLabel *descriptionLabel = new QLabel(" Description", modifyCard);
        descriptionLabel->setGeometry(40, 365, 300, 24);
        descriptionLabel->setStyleSheet(MONO + "font-size:20px; font-weight:bold; color:#00eaff; background:transparent;");

        descriptionBox = new DescriptionBox(40, 395, 1080, 100, "Detailed crime description...", modifyCard);

        QLabel *statusLabel = new QLabel("Status", modifyCard);
        statusLabel->setGeometry(40, 510, 1100, 24);
        statusLabel->setStyleSheet(MONO + "font-size:20px; font-weight:bold; color:#7ab8e0; background:transparent;");

        ColoredButton *pendingBtn = new ColoredButton("PENDING", 40,  540, 350, 48, "#ffcc44", modifyCard);
        ColoredButton *solvedBtn  = new ColoredButton("SOLVED",  405, 540, 350, 48, "#44ff99", modifyCard);
        ColoredButton *coldBtn    = new ColoredButton("COLD",    770, 540, 350, 48, "#ff6666", modifyCard);

        message = new QLabel("", modifyCard);
        message->setGeometry(40, 595, 1100, 22);
        message->setStyleSheet(MONO + "font-size:16px; color:#00eaff; background:transparent;");

        saveButton   = new Button("SAVE", 40, 620, 350, 48, modifyCard);
        deleteButton = new ClearButton("DELETE", 770, 620, 350, 48, modifyCard);

        QObject::connect(loadButton, &QPushButton::clicked, [this]()
        {
            QString caseIdentifier = caseIDBox->text().trimmed();

            if (caseIdentifier.isEmpty())
            {
                setMessage("  Enter a Case ID.", "#ff6666");
                return;
            }

            QStringList recordParts = FileHandler::loadRecord(caseIdentifier);

            if (recordParts.isEmpty())
            {
                setMessage("  Case ID not found.", "#ff6666");
                return;
            }

            locationBox->setText(recordParts.value(1));
            typeBox->setText(recordParts.value(2));
            descriptionBox->setText(recordParts.value(3));
            selectedStatus = recordParts.value(4, "Pending");
            setMessage("  Record loaded. Edit and press Save.", "#44ff99");
        });

        QObject::connect(saveButton, &QPushButton::clicked, [this]()
        {
            QString caseIdentifier = caseIDBox->text().trimmed();
            QString crimeLocation = locationBox->text().trimmed();
            QString crimeType = typeBox->text().trimmed();
            QString crimeDescription = descriptionBox->toPlainText().trimmed();

            if (caseIdentifier.isEmpty() || crimeLocation.isEmpty() || crimeType.isEmpty())
            {
                setMessage("  Load a record first.", "#ff6666");
                return;
            }

            if (!FileHandler::caseIDExists(caseIdentifier))
            {
                setMessage("  Case ID not found.", "#ff6666");
                return;
            }

            FileHandler::updateRecord(caseIdentifier, crimeLocation, crimeType, crimeDescription, selectedStatus);
            setMessage("  Record updated successfully!", "#44ff99");
        });

        QObject::connect(deleteButton, &QPushButton::clicked, [this]()
        {
            QString caseIdentifier = caseIDBox->text().trimmed();

            if (caseIdentifier.isEmpty())
            {
                setMessage("  Load a record first.", "#ff6666");
                return;
            }

            QMessageBox confirm;
            
            confirm.setWindowTitle("Confirm Delete");
            confirm.setText("Delete case " + caseIdentifier + "?");
            confirm.setInformativeText("This action cannot be undone.");
            confirm.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
            confirm.setDefaultButton(QMessageBox::No);

            if (confirm.exec() != QMessageBox::Yes)
            {
                return;
            }

            if (FileHandler::deleteRecord(caseIdentifier))
            {
                setMessage("  Record deleted.", "#ffcc44");
                reset();
            }
            else
            {
                setMessage("  Case ID not found.", "#ff6666");
            }
        });
    }

    void reset()
    {
        caseIDBox->clear();
        locationBox->clear();
        typeBox->clear();
        descriptionBox->clear();
        selectedStatus = "Pending";
        message->setText("");
    }
};

// =============================================================================
//  CRIME RECORD PAGE
// =============================================================================

class CrimeRecordPage : public QWidget
{
private:

    QLabel *img;
    bool isAdminRole;

    Card *newRecordCard;
    QLabel *newRecordHeading;
    QLabel *createLine;
    QLabel *caseIDLabel;
    Box *caseIDBox;
    QLabel *locationLabel;
    Box *locationBox;
    QLabel *crimeTypeLabel;
    Box *typeBox;
    QLabel *descLabel;
    DescriptionBox *descriptionBox;
    QLabel *footNote;
    QLabel *feedback;
    QPushButton *save;
    QPushButton *clear;

    QWidget *createPanelContainer;

    View *viewWidget;
    Search *searchWidget;
    Sort *sortWidget;
    Modify *modifyWidget;

    Button *recordButtons[5];

    void hideAllPanels()
    {
        createPanelContainer->hide();
        viewWidget->hide();
        searchWidget->hide();
        sortWidget->hide();
        modifyWidget->hide();
    }

public:
    CrimeRecordPage(bool isAdmin) : isAdminRole(isAdmin)
    {
        setWindowTitle("Crime Records - CRIME RECORD MANAGEMENT SYSTEM");

        img = UI::setupBackground(this, "backgroundThree.png");

        UI::setupSidebar(this, "[ CRIME RECORDS ]");
        UI::setupPageHeader(this, "CRIME RECORD MANAGEMENT", "Manage and track criminal data across the jurisdiction");
        UI::setupFooter(this);

        for (int i = 0; i < 5; i++)
        {
            recordButtons[i] = nullptr;
        }

        if (isAdmin)
        {
            const char *items[] = {
                "  Create New Record", "  View All Records",
                "  Search Records", "  Sort Records", "  Modify / Delete"
            };
            
            for (int i = 0; i < 5; i++)
            {
                recordButtons[i] = new Button(items[i], 25, 155 + i * 60, 270, 40, this);
            }
            
            BackButton *bb = new BackButton(25, 155 + 5 * 60, 270, 44, this);
            bb->raise();
        }
        else
        {
            const char *items[] = {
                "  View All Records", "  Search Records", "  Sort Records"
            };
            
            for (int i = 0; i < 3; i++)
            {
                recordButtons[i] = new Button(items[i], 25, 155 + i * 60, 270, 40, this);
            }
            
            BackButton *bb = new BackButton(25, 155 + 3 * 60, 270, 44, this);
            bb->raise();
        }

        createPanelContainer = new QWidget(this);
        createPanelContainer->setGeometry(320, 0, 1280, 900);
        createPanelContainer->hide();

        // ── Standardized Card with parameter-based title ──
        newRecordCard = new Card(100, 150, 670, 650, createPanelContainer, "CREATE NEW CRIME RECORD");

        auto makeFieldLabel = [this](const QString &text, int yPosition) -> QLabel*
        {
            QLabel *featureLabel = new QLabel(text, newRecordCard);
            featureLabel->setGeometry(20, yPosition, 300, 24);
            featureLabel->setStyleSheet(MONO + "font-size:20px; font-weight:bold; color:#00eaff; background:transparent;");
            return featureLabel;
        };

        caseIDLabel    = makeFieldLabel(" Case ID  *", 80);
        locationLabel  = makeFieldLabel(" Location  *", 180);
        crimeTypeLabel = makeFieldLabel(" Crime Type  *", 280);
        descLabel      = makeFieldLabel(" Description", 380);

        caseIDBox      = new Box(20, 115, 630, 38, "e.g. CR-001", newRecordCard);
        locationBox    = new Box(20, 215, 630, 38, "e.g. Islamabad", newRecordCard);
        typeBox        = new Box(20, 315, 630, 38, "e.g. Robbery", newRecordCard);
        descriptionBox = new DescriptionBox(20, 415, 630, 100, "Detailed crime description...", newRecordCard);

        footNote = new QLabel("  Status is automatically set to 'Pending'", newRecordCard);
        footNote->setGeometry(160, 540, 630, 22);
        footNote->setStyleSheet(
            MONO +
            "font-size:15px; color:#ffcc44; background:transparent;"
        );

        feedback = new QLabel("", newRecordCard);
        feedback->setGeometry(80, 565, 630, 22);
        feedback->setStyleSheet(
            MONO +
            "font-size:16px; color:#00eaff; background:transparent;"
        );

        save  = new Button("SAVE", 20, 610, 180, 44, newRecordCard);
        clear = new ClearButton("CLEAR", 470, 610, 180, 44, newRecordCard);

        viewWidget = new View(isAdminRole, this);
        
        viewWidget->setGeometry(340, 110, 1200, 720);
        viewWidget->hide();

        searchWidget = new Search(isAdminRole, this);
        
        searchWidget->setGeometry(340, 110, 1200, 760);
        searchWidget->hide();

        sortWidget = new Sort(isAdminRole, this);
        
        sortWidget->setGeometry(340, 110, 1200, 760);
        sortWidget->hide();

        modifyWidget = new Modify(this);
        
        modifyWidget->setGeometry(340, 110, 1200, 720);
        modifyWidget->hide();

        if (isAdminRole)
        {
            QObject::connect(recordButtons[0], &QPushButton::clicked, [this]()
            {
                hideAllPanels();
                createPanelContainer->show();
            });

            QObject::connect(recordButtons[1], &QPushButton::clicked, [this]()
            {
                hideAllPanels();
                viewWidget->show();
            });

            QObject::connect(recordButtons[2], &QPushButton::clicked, [this]()
            {
                hideAllPanels();
                searchWidget->show();
            });

            QObject::connect(recordButtons[3], &QPushButton::clicked, [this]()
            {
                hideAllPanels();
                sortWidget->show();
            });

            QObject::connect(recordButtons[4], &QPushButton::clicked, [this]()
            {
                hideAllPanels();
                modifyWidget->reset();
                modifyWidget->show();
            });
        }
        else
        {
            QObject::connect(recordButtons[0], &QPushButton::clicked, [this]()
            {
                hideAllPanels();
                viewWidget->show();
            });

            QObject::connect(recordButtons[1], &QPushButton::clicked, [this]()
            {
                hideAllPanels();
                searchWidget->show();
            });

            QObject::connect(recordButtons[2], &QPushButton::clicked, [this]()
            {
                hideAllPanels();
                sortWidget->show();
            });
        }

        QObject::connect(clear, &QPushButton::clicked, [this]()
        {
            caseIDBox->clear();
            locationBox->clear();
            typeBox->clear();
            descriptionBox->clear();
            feedback->setText("");
        });

        QObject::connect(save, &QPushButton::clicked, [this]()
        {
            QString caseIdentifier = caseIDBox->text().trimmed();
            QString crimeLocation = locationBox->text().trimmed();
            QString crimeType = typeBox->text().trimmed();
            QString crimeDescription = descriptionBox->toPlainText().trimmed();

            if (caseIdentifier.isEmpty() || crimeLocation.isEmpty() || crimeType.isEmpty())
            {
                feedback->setStyleSheet(MONO + "font-size:12px; color:#ff6666; background:transparent;");
                feedback->setText("  Case ID, Location and Crime Type are required.");
                return;
            }

            if (FileHandler::caseIDExists(caseIdentifier))
            {
                feedback->setStyleSheet(MONO + "font-size:12px; color:#ff6666; background:transparent;");
                feedback->setText("  Case ID already exists. Use a different ID.");
                return;
            }

            FileHandler::saveRecord(caseIdentifier, crimeLocation, crimeType, crimeDescription);
            
            feedback->setStyleSheet(MONO + "font-size:12px; color:#44ff99; background:transparent;");
            feedback->setText("  Record saved successfully!");

            caseIDBox->clear();
            locationBox->clear();
            typeBox->clear();
            descriptionBox->clear();
        });
    }

    void resizeEvent(QResizeEvent *) override
    {
        img->setGeometry(0, 0, width(), height());
    }
};

#endif // CRIMERECORDS_H