#ifndef VALIDITY_H
#define VALIDITY_H

#include <cstring>
#include <QString>
#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QList>
#include <functional>
#include <QTimer>

// Forward declaration of MONO if not available, or just use the string literal
#ifndef MONO_FONT
#define MONO_FONT "font-family: 'Consolas', 'Monaco', 'Courier New', monospace;"
#endif

// ── Validation Popup ─────────────────────────────────────────────────────────

class ValidationPopup : public QWidget
{
private:
    struct Rule {
        QString description;
        std::function<bool(QString)> condition;
        QLabel* label;
    };
    QList<Rule> rules;
    QLabel* titleLabel;

public:
    virtual ~ValidationPopup() {}
    ValidationPopup(QWidget* parent, const QString& title) : QWidget(parent)
    {
        setFixedWidth(300);
        setStyleSheet("background:rgba(3, 12, 35, 0.98); border:1px solid #00eaff; border-radius:8px;");
        
        titleLabel = new QLabel(title, this);
        titleLabel->setGeometry(10, 5, 280, 25);
        titleLabel->setStyleSheet(QString(MONO_FONT) + "font-size:13px; font-weight:bold; color:#ffcc44; border:none; background:transparent;");
        
        hide();
    }

    void addRule(const QString& description, std::function<bool(QString)> condition)
    {
        Rule r;
        r.description = description;
        r.condition = condition;
        r.label = new QLabel("✘ " + description, this);
        r.label->setGeometry(15, 30 + (rules.size() * 20), 270, 20);
        r.label->setStyleSheet(QString(MONO_FONT) + "font-size:11px; color:#ff6666; border:none; background:transparent;");
        rules.append(r);
        setFixedHeight(40 + (rules.size() * 20));
    }

    inline static ValidationPopup* activePopup = nullptr;

    void attachTo(QLineEdit* input)
    {
        input->installEventFilter(this);

        auto updateRules = [this, input](const QString& text)
        {
            if (activePopup && activePopup != this) activePopup->hide();
            activePopup = this;

            for (auto& r : rules)
            {
                if (r.condition(text))
                {
                    r.label->setStyleSheet(QString(MONO_FONT) + "font-size:11px; color:#44ff99; border:none; background:transparent;");
                    r.label->setText("✔ " + r.description);
                }
                else
                {
                    r.label->setStyleSheet(QString(MONO_FONT) + "font-size:11px; color:#ff6666; border:none; background:transparent;");
                    r.label->setText("✘ " + r.description);
                }
            }
            show();
            move(input->x() - width() - 10, input->y());
            raise();
        };

        connect(input, &QLineEdit::textChanged, this, updateRules);
    }

protected:
    bool eventFilter(QObject* obj, QEvent* event) override
    {
        QLineEdit* input = qobject_cast<QLineEdit*>(obj);
        if (!input) return QWidget::eventFilter(obj, event);

        // Hides when clicking "anywhere else" (FocusOut)
        if (event->type() == QEvent::FocusOut)
        {
            hide();
            if (activePopup == this) activePopup = nullptr;
        }
        // Shows when clicking inside (FocusIn or MouseButtonPress)
        else if (event->type() == QEvent::FocusIn || event->type() == QEvent::MouseButtonPress)
        {
            // Update rules before showing
            for (auto& r : rules) {
                if (r.condition(input->text())) {
                    r.label->setStyleSheet(QString(MONO_FONT) + "font-size:11px; color:#44ff99; border:none; background:transparent;");
                    r.label->setText("✔ " + r.description);
                } else {
                    r.label->setStyleSheet(QString(MONO_FONT) + "font-size:11px; color:#ff6666; border:none; background:transparent;");
                    r.label->setText("✘ " + r.description);
                }
            }

            if (activePopup && activePopup != this) activePopup->hide();
            activePopup = this;
            show();
            move(input->x() - width() - 10, input->y());
            raise();
        }
        return QWidget::eventFilter(obj, event);
    }
};


class Validator
{
protected:
    char* message = nullptr;

    void setMsg(const char* m)
    {
        delete[] message;
        message = new char[strlen(m) + 1];
        strcpy(message, m);
    }

public:
    Validator()
    {
        setMsg("");
    }

    virtual ~Validator()
    {
        delete[] message;
    }

    virtual bool validate() = 0;

    const char* getMessage() const
    {
        return message;
    }
};

class EmailValidator : public Validator
{
private:
    char* email = nullptr;

public:
    ~EmailValidator()
    {
        delete[] email;
    }

    void setEmail(const char* input)
    {
        delete[] email;
        if (input)
        {
            email = new char[strlen(input) + 1];
            strcpy(email, input);
        }
        else
        {
            email = nullptr;
        }
        setMsg("");
    }

    bool validate() override
    {
        if (!email || strlen(email) == 0)
        {
            setMsg("Email is empty.");
            return false;
        }

        if (!strchr(email, '@'))
        {
            setMsg("Missing '@' symbol.");
            return false;
        }

        int len = strlen(email);
        if (len < 5 || (strcmp(email + len - 4, ".com") != 0 && strcmp(email + len - 4, ".net") != 0))
        {
            setMsg("Email must end with .com or .net");
            return false;
        }

        setMsg("Valid Email");
        return true;
    }
};

class PasswordValidator : public Validator
{
private:
    char* pass = nullptr;

public:
    ~PasswordValidator()
    {
        delete[] pass;
    }

    void setPassword(const char* input)
    {
        delete[] pass;
        if (input)
        {
            pass = new char[strlen(input) + 1];
            strcpy(pass, input);
        }
        else
        {
            pass = nullptr;
        }
        setMsg("");
    }

    bool validate() override
    {
        if (!pass || strlen(pass) < 8)
        {
            setMsg("Password must be at least 8 characters.");
            return false;
        }

        bool hasUpper = false;
        bool hasDigit = false;

        for (int i = 0; pass[i] != '\0'; i++)
        {
            if (pass[i] >= 'A' && pass[i] <= 'Z')
            {
                hasUpper = true;
            }
            if (pass[i] >= '0' && pass[i] <= '9')
            {
                hasDigit = true;
            }
        }

        if (!hasUpper)
        {
            setMsg("Must have at least one UPPERCASE letter.");
            return false;
        }

        if (!hasDigit)
        {
            setMsg("Must have at least one digit (0-9).");
            return false;
        }

        setMsg("Strong Password");
        return true;
    }
};

class UsernameValidator : public Validator
{
private:
    char* user = nullptr;

public:
    ~UsernameValidator()
    {
        delete[] user;
    }

    void setUsername(const char* input)
    {
        delete[] user;
        if (input)
        {
            user = new char[strlen(input) + 1];
            strcpy(user, input);
        }
        else
        {
            user = nullptr;
        }
        setMsg("");
    }

    bool validate() override
    {
        if (!user)
        {
            setMsg("Username is empty.");
            return false;
        }

        int len = strlen(user);

        if (len < 3)
        {
            setMsg("Username too short (min 3).");
            return false;
        }

        for (int i = 0; user[i] != '\0'; i++)
        {
            char c = user[i];
            bool isAlnum = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9');

            if (!isAlnum && c != '_')
            {
                setMsg("Only letters, numbers, and '_' allowed.");
                return false;
            }
        }

        setMsg("Valid Username");
        return true;
    }
};
// Add this class to your validation file
class ValidationRules
{
public:
    static bool hasMinimumLength(const QString& text, int min)
    {
        return text.length() >= min;
    }
    static bool hasNoSpaces(const QString& text)
    {
        return !text.contains(' ');
    }
    static bool containsAtSymbol(const QString& text)
    {
        return text.contains('@');
    }
    static bool containsDotAfterAt(const QString& text)
    {
        int atIndex = text.indexOf('@');
        if (atIndex == -1)
        {
            return false;
        }
        return text.indexOf('.', atIndex) != -1;
    }
    static bool hasUppercase(const QString& text)
    {
        for (const QChar& c : text)
        {
            if (c.isUpper())
            {
                return true;
            }
        }
        return false;
    }
    static bool hasLowercase(const QString& text)
    {
        for (const QChar& c : text)
        {
            if (c.isLower())
            {
                return true;
            }
        }
        return false;
    }
    static bool hasDigit(const QString& text)
    {
        for (const QChar& c : text)
        {
            if (c.isDigit())
            {
                return true;
            }
        }
        return false;
    }
    static bool hasSpecialCharacter(const QString& text)
    {
        for (const QChar& c : text)
        {
            if (!c.isLetterOrNumber() && !c.isSpace())
            {
                return true;
            }
        }
        return false;
    }
    static bool hasNoLeadingOrTrailingSpaces(const QString& text)
    {
        return text == text.trimmed();
    }
};


#endif