#ifndef CRIMESTATUS_H
#define CRIMESTATUS_H

#include <QStackedWidget>
#include <QResizeEvent>
#include "common.h"
#include "file.h"

static QString formatStatusRecord(const QStringList &parts)
{
    if (parts.size() < 5) return "";
    return "  Case ID  : " + parts[0].trimmed() + "\n" +
           "  Location : " + parts[1].trimmed() + "\n" +
           "  Type     : " + parts[2].trimmed() + "\n" +
           "  Status   : " + parts[4].trimmed() + "\n" +
           "  --------------------------------------------------\n";
}

class Update : public QWidget
{

private:
    Box         * caseIDInput;
    Button      * loadButton;
    ColoredButton * solvedButton;
    ColoredButton * pendingButton;
    ColoredButton * coldButton;
    QLabel      * feedbackLabel;
    QString       currentCaseID;
    QString       selectedStatus;
    bool          isRecordLoaded;
    std::function<void()> onStatusChanged;

    void updateFeedback(const QString & message)
    {
        feedbackLabel->setText("  " + message);
    }

public:
    Update(QWidget * parent = nullptr): QWidget(parent), currentCaseID(""), selectedStatus("Pending")
, isRecordLoaded(false)
        , onStatusChanged(nullptr)
    {
        new Card(20, 0, 1125, 340, this);

        QLabel * title = new QLabel("UPDATE CASE STATUS", this);
        title->setGeometry(40, 18, 1100, 28);
        title->setStyleSheet
        (
            MONO +
            "font-size   : 18px;"
            "font-weight : bold;"
            "color       : #ffcc44;"
            "background  : transparent;"
        );

        QLabel * divider = new QLabel(this);
        divider->setGeometry(40, 52, 1100, 1);
        divider->setStyleSheet("background : rgba(255, 200, 0, 0.20);");

        QLabel * caseIDLabel = new QLabel("Case ID", this);
        caseIDLabel->setGeometry(40, 68, 300, 24);
        caseIDLabel->setStyleSheet
        (
            MONO +
            "font-size   : 20px;"
            "font-weight : bold;"
            "color       : #a0d8f0;"
            "background  : transparent;"
        );

        caseIDInput  = new Box(40, 94, 900, 38, "Enter Case ID", this);
        loadButton = new Button("Load", 960, 94, 160, 38, this);

        feedbackLabel = new QLabel("", this);
        feedbackLabel->setGeometry(40, 140, 1100, 22);
        feedbackLabel->setStyleSheet
        (
            MONO +
            "font-size  : 16px;"
            "color      : #c0dff5;"
            "background : transparent;"
        );

        QLabel * statusLabel = new QLabel("New Status", this);
        statusLabel->setGeometry(40, 172, 300, 24);
        statusLabel->setStyleSheet
        (
            MONO +
            "font-size   : 20px;"
            "font-weight : bold;"
            "color       : #a0d8f0;"
            "background  : transparent;"
        );

        solvedButton  = new ColoredButton("SOLVED",  40,  204, 350, 48, "#44ff99", this);
        pendingButton = new ColoredButton("PENDING", 415, 204, 350, 48, "#ffcc44", this);
        coldButton    = new ColoredButton("COLD",    790, 204, 350, 48, "#ff6666", this);

        Button * saveButton = new Button("SAVE CHANGES", 40, 270, 350, 52, this);

        connect(loadButton, &QPushButton::clicked, this, [this]()
            {
                QString id = caseIDInput->text().trimmed();

                if (id.isEmpty())
                {
                    updateFeedback("Enter a Case ID first.");
                    return;
                }

                QStringList parts = FileHandler::loadRecord(id);

                if (parts.isEmpty())
                {
                    updateFeedback("Case ID not found.");
                    isRecordLoaded = false;
                    currentCaseID = "";
                    return;
                }

                currentCaseID  = id;
                selectedStatus = (parts.size() >= 5) ? parts[4] : "Pending";
                isRecordLoaded = true;

                updateFeedback
                (
                    QString("Loaded: %1   |   Current status: %2")
                    .arg(parts[0])
                    .arg(selectedStatus)
                );
            }
        );

        connect(solvedButton, &QPushButton::clicked, this, [this]()
            {
                selectedStatus = "Solved";
                updateFeedback("Status selected: SOLVED");
            }
        );

        connect(pendingButton, &QPushButton::clicked, this, [this]()
            {
                selectedStatus = "Pending";
                updateFeedback("Status selected: PENDING");
            }
        );

        connect(coldButton, &QPushButton::clicked, this, [this]()
            {
                selectedStatus = "Cold";
                updateFeedback("Status selected: COLD");
            }
        );

        connect(saveButton, &QPushButton::clicked, this, [this]()
            {
                if (!isRecordLoaded)
                {
                    updateFeedback("Load a valid record before saving.");
                    return;
                }
                
                if (currentCaseID.isEmpty())
                {
                    updateFeedback("Load a valid record before saving.");
                    return;
                }

                if (FileHandler::updateStatus(currentCaseID, selectedStatus))
                {
                    FileHandler::appendLog
                    (
                        "ADMIN",
                        QString("Status updated — Case ID: %1 → %2")
                        .arg(currentCaseID)
                        .arg(selectedStatus)
                    );

                    updateFeedback
                    (
                        QString("Status updated to %1 successfully!")
                        .arg(selectedStatus.toUpper())
                    );

                    if (onStatusChanged) onStatusChanged();
                }
                else
                {
                    updateFeedback("Failed to update. Case ID not found.");
                }
            }
        );
    }

public:
    void setOnStatusChanged(std::function<void()> callback) { onStatusChanged = callback; }
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  VIEW PANEL (Display all records)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class StatusView : public QWidget
{
private:
    Button    * refreshButton;
    RecordDisplay * resultDisplay;

public:
    StatusView(QWidget * parent = nullptr) : QWidget(parent)
    {
        QLabel * heading = new QLabel("ALL CASES WITH STATUS", this);
        heading->setGeometry(0, 8, 860, 30);
        heading->setStyleSheet
        (
            MONO +
            "font-size   : 18px;"
            "font-weight : bold;"
            "color       : #00eaff;"
            "background  : transparent;"
        );

        refreshButton = new Button("REFRESH", 1005, 6, 140, 34, this);
        resultDisplay = new RecordDisplay(0, 50, 1150, 485, this, "  Click REFRESH to load all records.");

        connect(refreshButton, &QPushButton::clicked, this, [this]()
            {
                loadAndDisplay();
            }
        );
    }

    void loadAndDisplay()
    {
        QStringList records = FileHandler::loadRecords();

        if (records.isEmpty())
        {
            resultDisplay->setText("  No records found.");
            return;
        }

        QString displayText;
        for (const QString & recordLine : records)
        {
            displayText += formatStatusRecord(recordLine.split("\t"));
        }

        resultDisplay->setText(displayText);
    }
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  FILTER PANEL (Display specific status)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class Filter : public QWidget
{
private:
    ColoredButton * solvedButton;
    ColoredButton * pendingButton;
    ColoredButton * coldButton;
    RecordDisplay * resultDisplay;

    void filterByStatus(const QString & status)
    {
        QStringList records = FileHandler::loadRecords();
        QString     displayText;

        for (const QString & recordLine : records)
        {
            QStringList parts = recordLine.split("\t");

            if (parts.size() >= 5)
            {
                if (parts[4].toLower() == status.toLower())
                {
                    displayText += formatStatusRecord(parts);
                }
            }
        }

        if (displayText.isEmpty())
        {
            resultDisplay->setText("  No " + status + " cases found.");
        }
        else
        {
            resultDisplay->setText(displayText);
        }
    }

public:
    Filter(QWidget * parent = nullptr) : QWidget(parent)
    {
        new Card(170, 0, 800, 128, this);

        QLabel * heading = new QLabel("FILTER BY STATUS", this);
        heading->setGeometry(190, 18, 760, 28);
        heading->setStyleSheet
        (
            MONO +
            "font-size   : 18px;"
            "font-weight : bold;"
            "color       : #00eaff;"
            "background  : transparent;"
        );

        QLabel * divider = new QLabel(this);
        divider->setGeometry(190, 52, 760, 1);
        divider->setStyleSheet("background : rgba(0, 200, 255, 0.20);");

        solvedButton  = new ColoredButton("SOLVED",  190, 68, 250, 52, "#44ff99", this);
        pendingButton = new ColoredButton("PENDING", 445, 68, 250, 52, "#ffcc44", this);
        coldButton    = new ColoredButton("COLD",    700, 68, 250, 52, "#ff6666", this);

        resultDisplay = new RecordDisplay(0, 160, 1150, 380, this, "  Press a filter button above to view cases.");

        connect(solvedButton,  &QPushButton::clicked, this, [this]() { filterByStatus("Solved");  });
        connect(pendingButton, &QPushButton::clicked, this, [this]() { filterByStatus("Pending"); });
        connect(coldButton,    &QPushButton::clicked, this, [this]() { filterByStatus("Cold");    });
    }
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  CASE STATUS DASHBOARD
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class CaseStatusPage : public QWidget
{
private:
    QLabel         * backgroundImage;
    QStackedWidget * pageStack;
    StatusView     * viewPanel;
    Filter         * filterPanel;
    Update         * updatePanel;
    
    Button         * viewButton;
    Button         * filterButton;
    Button         * updateButton;
    StatCard       * solvedStats;
    StatCard       * pendingStats;
    StatCard       * coldStats;

    void refreshStatistics()
    {
        QStringList records = FileHandler::loadRecords();

        int solvedCount  = 0;
        int pendingCount = 0;
        int coldCount    = 0;

        for (const QString & recordLine : records)
        {
            QStringList parts = recordLine.split("\t");
            
            if (parts.size() >= 5)
            {
                QString status = parts[4].trimmed().toLower();
                
                if (status == "solved")
                {
                    solvedCount++;
                }
                else if (status == "pending")
                {
                    pendingCount++;
                }
                else if (status == "cold")
                {
                    coldCount++;
                }
            }
        }

        solvedStats->setValue(solvedCount);
        pendingStats->setValue(pendingCount);
        coldStats->setValue(coldCount);
    }

public:
    CaseStatusPage(bool isAdmin) : QWidget(nullptr)
    {
        setWindowTitle("Case Status — CRIME RECORD MANAGEMENT SYSTEM");

        backgroundImage = UI::setupBackground(this, "backgroundThree.png");

        new Card(0, 0, 320, 900, this);

        QLabel * sidebarTitle = new QLabel("CRIME RECORD\nMANAGEMENT\nSYSTEM", this);
        sidebarTitle->setGeometry(10, 10, 300, 120);
        sidebarTitle->setAlignment(Qt::AlignCenter);
        sidebarTitle->setWordWrap(true);
        sidebarTitle->setStyleSheet(MONO + "font-size:20px; font-weight:bold; letter-spacing:1px; color:#00eaff; background:transparent;");

        QLabel * dividerOne = new QLabel(this);
        dividerOne->setGeometry(30, 100, 260, 1);
        dividerOne->setStyleSheet("background:rgba(0,200,255,0.30);");

        QLabel * tag = new QLabel("[ CASE  STATUS ]", this);
        tag->setGeometry(0, 110, 320, 30);
        tag->setAlignment(Qt::AlignCenter);
        tag->setStyleSheet(MONO + "font-size:18px; letter-spacing:4px; color:#ffcc44; font-weight:bold; background:transparent;");

        QLabel * pageTitle = new QLabel("CASE STATUS DASHBOARD", this);
        pageTitle->setGeometry(380, 40, 1180, 50);
        pageTitle->setStyleSheet(MONO + "font-size:36px; font-weight:900; letter-spacing:6px; color:#ffffff; background:transparent;");

        QLabel * pageSub = new QLabel("Real-time monitoring of all active and resolved criminal cases", this);
        pageSub->setGeometry(380, 95, 1180, 22);
        pageSub->setStyleSheet(MONO + "font-size:18px; font-weight:bold; color:#7ab8e0; background:transparent;");

        solvedStats  = new StatCard(380,  140, "#44ff99", "SOLVED",     this);
        pendingStats = new StatCard(850,  140, "#ffcc44", "PENDING",    this);
        coldStats    = new StatCard(1300, 140, "#ff6666", "COLD CASES", this);

        viewButton   = new Button("View Status",   25, 300, 270, 40, this);
        filterButton = new Button("Filter Cases", 25, 360, 270, 40, this);
        updateButton = nullptr;

        if (isAdmin)
        {
            updateButton = new Button("Update Status", 25, 420, 270, 40, this);
        }

        BackButton * backButton = new BackButton(25, isAdmin ? 480 : 420, 270, 44, this);
        backButton->raise();

        connect(backButton, &QPushButton::clicked, this, [this]() 
            { 
                this->close(); 
            }
        );

        UI::setupFooter(this);

        pageStack = new QStackedWidget(this);
        pageStack->setGeometry(380, 250, 1150, 630);
        pageStack->setStyleSheet("background : transparent;");

        viewPanel = new StatusView(pageStack);
        filterPanel = new Filter(pageStack);
        updatePanel = new Update(pageStack);

        pageStack->addWidget(viewPanel);
        pageStack->addWidget(filterPanel);
        pageStack->addWidget(updatePanel);
        pageStack->setCurrentIndex(0);

        refreshStatistics();

        connect(viewButton, &QPushButton::clicked, this, [this]()
            {
                refreshStatistics();
                viewPanel->loadAndDisplay();
                pageStack->setCurrentIndex(0);
            }
        );

        connect(filterButton, &QPushButton::clicked, this, [this]()
            {
                refreshStatistics();
                pageStack->setCurrentIndex(1);
            }
        );

        if (isAdmin && updateButton != nullptr)
        {
            connect(updateButton, &QPushButton::clicked, this, [this]()
                {
                    pageStack->setCurrentIndex(2);
                }
            );

            updatePanel->setOnStatusChanged([this]()
                {
                    refreshStatistics();
                }
            );
        }
    }

    void resizeEvent(QResizeEvent * event) override
    {
        if (backgroundImage)
        {
            backgroundImage->resize(event->size());
        }
    }
};

#endif