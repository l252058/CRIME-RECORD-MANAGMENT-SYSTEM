#ifndef COMMON_H
#define COMMON_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>
#include <QTextEdit>
#include <QScrollArea>
#include <QPropertyAnimation>
#include <QGraphicsDropShadowEffect>
#include <QPainter>
#include <QPixmap>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QCoreApplication>
#include <QString>
#include <QStringList>
#include <QChar>
#include <QTimer>
#include <QMessageBox>
#include <functional>

#include "file.h"

// ── Global Aesthetic Settings ────────────────────────────────────────────────

const QString MONO = "font-family: 'Consolas', 'Monaco', 'Courier New', monospace;";

// Helper to load images safely - uses multiple strategies to locate assets
inline static QPixmap loadPixmap(const QString& fileName)
{
    if (fileName.isEmpty()) return QPixmap();

    QStringList attempts;
    attempts << fileName;
    attempts << ":/" + fileName; 
    
    // Check various directory depths to escape build/debug folders
    QString searchDir = QCoreApplication::applicationDirPath();
    for (int i = 0; i < 6; ++i)
    {
        attempts << searchDir + "/" + fileName;
        attempts << searchDir + "/images/" + fileName;
        attempts << searchDir + "/assets/" + fileName;
        
        QString parent = QFileInfo(searchDir).absolutePath();
        if (parent == searchDir) break;
        searchDir = parent;
    }
    
    // Absolute Path Fallbacks
    attempts << QCoreApplication::applicationDirPath() + "/../../../" + fileName;
    attempts << "C:/Users/Ubaid Ullah/Documents/OOP_Project/" + fileName;
    attempts << "C:/Users/Ubaid Ullah/Documents/OOP_Project/images/" + fileName;
    attempts << QDir::currentPath() + "/" + fileName;

    for (const QString& path : attempts)
    {
        if (QFile::exists(path))
        {
            QPixmap pix;
            if (pix.load(path) && !pix.isNull())
            {
                return pix;
            }
        }
    }
    
    return QPixmap();
}

// ── Sound Management ─────────────────────────────────────────────────────────

class SoundManager
{
public:
    static void play(const QString& soundFile) 
    { 
        (void)soundFile; 
    }
};

// ── UI Components ────────────────────────────────────────────────────────────

class Card : public QWidget
{
public:
    Card(int x, int y, int width, int height, QWidget* parent, const QString& title = "") : QWidget(parent)
    {
        setGeometry(x, y, width, height);
        setStyleSheet(
            "background    : rgba(0, 8, 24, 0.98);"
            "border        : 1px solid rgba(0, 234, 255, 0.5);"
            "border-radius : 15px;"
        );
        
        QGraphicsDropShadowEffect* shadow = new QGraphicsDropShadowEffect(this);
        shadow->setBlurRadius(25);
        shadow->setColor(QColor(0, 234, 255, 30));
        shadow->setOffset(0, 6);
        setGraphicsEffect(shadow);

        if (!title.isEmpty())
        {
            QLabel *titleLabel = new QLabel(title, this);
            titleLabel->setGeometry(20, 18, width - 40, 28);
            titleLabel->setStyleSheet(MONO + "font-size:20px; font-weight:bold; color:#00eaff; background:transparent;");

            QLabel *line = new QLabel(this);
            line->setGeometry(15, 52, width - 30, 1);
            line->setStyleSheet("background:rgba(0, 234, 255, 0.2);");
        }

        show();
    }
};

class Button : public QPushButton
{
public:
    Button(const QString& text, int x, int y, int width, int height, QWidget* parent) : QPushButton(text, parent)
    {
        setGeometry(x, y, width, height);
        setStyleSheet(
            "QPushButton {"
            "    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #005577, stop:1 #002233);"
            "    color: #00eaff;"
            "    border: 1px solid #00eaff;"
            "    border-radius: 6px;"
            "    font-weight: bold;"
            "    font-size: 14px;"
            "    letter-spacing: 1px;"
            "}"
            "QPushButton:hover { background: #00eaff; color: #001122; }"
            "QPushButton:pressed { background: #00ccff; padding-top: 2px; }"
        );
    }
    void setSound(const QString& soundFile) { SoundManager::play(soundFile); }
};

class ColoredButton : public QPushButton
{
public:
    ColoredButton(const QString& text, int x, int y, int width, int height, const QString& color, QWidget* parent) 
        : QPushButton(text, parent)
    {
        setGeometry(x, y, width, height);
        setStyleSheet(
            "QPushButton {"
            "    background: transparent;"
            "    color: " + color + ";"
            "    border: 1px solid " + color + ";"
            "    border-radius: 6px;"
            "    font-weight: bold;"
            "    font-size: 14px;"
            "}"
            "QPushButton:hover { background: " + color + "; color: #ffffff; }"
        );
    }
};

class ClearButton : public QPushButton
{
public:
    ClearButton(const QString& text, int x, int y, int width, int height, QWidget* parent) : QPushButton(text, parent)
    {
        setGeometry(x, y, width, height);
        setStyleSheet(
            "QPushButton {"
            "    background: #ff4444;"
            "    color: white;"
            "    border-radius: 6px;"
            "    font-weight: bold;"
            "    font-size: 14px;"
            "}"
            "QPushButton:hover { background: #ff2222; }"
        );
    }
    void setSound(const QString& soundFile) { SoundManager::play(soundFile); }
};

class BackButton : public QPushButton
{
public:
    BackButton(int x, int y, int width, int height, QWidget* parent) : QPushButton("  ←  RETURN", parent)
    {
        setGeometry(x, y, width, height);
        setStyleSheet(
            "QPushButton {"
            "    background: rgba(255, 255, 255, 0.05);"
            "    color: #7ab8e0;"
            "    border: 1px solid rgba(122, 184, 224, 0.3);"
            "    border-radius: 6px;"
            "    font-weight: bold;"
            "    font-size: 14px;"
            "}"
            "QPushButton:hover { background: rgba(255, 255, 255, 0.1); color: white; }"
        );
    }
};

class Box : public QLineEdit
{
public:
    Box(int x, int y, int width, int height, const QString& placeholder, QWidget* parent) : QLineEdit(parent)
    {
        setPlaceholderText(placeholder);
        setGeometry(x, y, width, height);
        setStyleSheet(
            "QLineEdit {"
            "    background: rgba(0, 5, 20, 0.9);"
            "    border: 1px solid rgba(0, 200, 255, 0.35);"
            "    border-radius: 6px;"
            "    color: #ffffff;"
            "    padding-left: 12px;"
            "    font-size: 16px;"
            "    font-weight: bold;"
            "}"
            "QLineEdit:focus { border: 1px solid #00eaff; background: rgba(0, 25, 65, 0.9); }"
        );
    }
};

class DescriptionBox : public QTextEdit
{
public:
    DescriptionBox(int x, int y, int width, int height, const QString& placeholder, QWidget* parent) : QTextEdit(parent)
    {
        setPlaceholderText(placeholder);
        setGeometry(x, y, width, height);
        setStyleSheet(
            "QTextEdit {"
            "    background: rgba(0, 15, 45, 0.8);"
            "    border: 1px solid rgba(0, 200, 255, 0.3);"
            "    border-radius: 5px;"
            "    color: #ffffff;"
            "    font-size: 15px;"
            "    font-weight: bold;"
            "    padding: 8px;"
            "}"
            "QTextEdit:focus { border: 1px solid #00eaff; background: rgba(0, 25, 65, 0.9); }"
        );
    }
};

class StatCard : public QWidget
{
private:
    QLabel *numberLabel;
    QLabel *titleLabel;
public:
    StatCard(int x, int y, const QString &color, const QString &title, QWidget *parent) : QWidget(parent)
    {
        setGeometry(x, y, 400, 100);
        setStyleSheet("background:rgba(0, 8, 24, 0.98); border:1px solid " + color + "; border-radius:10px;");
        
        numberLabel = new QLabel("0", this);
        numberLabel->setGeometry(10, 10, 380, 50);
        numberLabel->setAlignment(Qt::AlignCenter);
        numberLabel->setStyleSheet("font-size:36px; font-weight:bold; color:" + color + "; background:transparent;");
        
        titleLabel = new QLabel(title, this);
        titleLabel->setGeometry(10, 60, 380, 25);
        titleLabel->setAlignment(Qt::AlignCenter);
        titleLabel->setStyleSheet(MONO + "font-size:16px; font-weight:bold; color:#7ab8e0; background:transparent;");
    }
    void setValue(int value) { numberLabel->setText(QString::number(value)); }
    void setText(const QString& text) { numberLabel->setText(text); }
};


class RecordDisplay : public QScrollArea
{
    QLabel* textLabel;
public:
    RecordDisplay(int x, int y, int width, int height, QWidget* parent, const QString& placeholder = "") : QScrollArea(parent)
    {
        setGeometry(x, y, width, height);
        setWidgetResizable(true);
        setStyleSheet("QScrollArea { background:transparent; border:none; }");

        textLabel = new QLabel(this);
        textLabel->setAlignment(Qt::AlignTop | Qt::AlignLeft);
        textLabel->setWordWrap(true);
        textLabel->setText(placeholder);
        textLabel->setStyleSheet(MONO + "font-size:16px; font-weight:bold; color:#c0dff5; padding:15px; background:rgba(0, 8, 24, 0.98); border:1px solid rgba(0, 234, 255, 0.35); border-radius:12px;");
        
        setWidget(textLabel);
    }
    void setText(const QString& text) { textLabel->setText(text); }
};

// ── Shared Utilities ─────────────────────────────────────────────────────────


inline void pureBubbleSort(QList<QStringList> &list, int column)
{
    int size = list.size();
    for (int indexI = 0; indexI < size - 1; indexI++)
    {
        for (int indexJ = 0; indexJ < size - indexI - 1; indexJ++)
        {
            if (list[indexJ].value(column).toLower() > list[indexJ + 1].value(column).toLower())
            {
                list.swapItemsAt(indexJ, indexJ + 1);
            }
        }
    }
}

class UI
{
public:
    static QLabel* setupBackground(QWidget* parent, const QString& fileName)
    {
        QLabel* backgroundImage = new QLabel(parent);
        backgroundImage->setGeometry(0, 0, 1600, 900);
        
        QPixmap pix = loadPixmap(fileName);
        if (pix.isNull())
        {
            // FALLBACK COLOR: If you see MAGENTA, it means the image file was not found.
            backgroundImage->setStyleSheet("background-color: #ff00ff;"); 
        }
        else
        {
            backgroundImage->setPixmap(pix);
            backgroundImage->setScaledContents(true);
        }
        
        backgroundImage->lower();
        backgroundImage->show();
        return backgroundImage;
    }

    static void setupSidebar(QWidget* parent, const QString& tagText)
    {
        new Card(0, 0, 320, 1000, parent);
        QLabel* title = new QLabel("CRIME RECORD\nMANAGEMENT\nSYSTEM", parent);
        title->setGeometry(10, 10, 300, 120);
        title->setAlignment(Qt::AlignCenter);
        title->setWordWrap(true);
        title->setStyleSheet(MONO + "font-size:20px; font-weight:bold; letter-spacing:1px; color:#00eaff; background:transparent;");

        QLabel* tag = new QLabel(tagText, parent);
        tag->setGeometry(0, 120, 320, 30);
        tag->setAlignment(Qt::AlignCenter);
        tag->setStyleSheet(MONO + "font-size:18px; letter-spacing:4px; color:#ffcc44; font-weight:bold; background:transparent;");
    }

    static void setupPageHeader(QWidget* parent, const QString& titleText, const QString& subText)
    {
        QLabel* title = new QLabel(titleText, parent);
        title->setGeometry(380, 40, 1180, 50);
        title->setStyleSheet(MONO + "font-size:40px; font-weight:900; letter-spacing:6px; color:#ffffff; background:transparent;");

        QLabel* sub = new QLabel(subText, parent);
        sub->setGeometry(380, 95, 1180, 22);
        sub->setStyleSheet(MONO + "font-size:18px; font-weight:bold; color:#7ab8e0; background:transparent;");
    }

    static void setupFooter(QWidget* parent)
    {
        QLabel* footer = new QLabel("DEPARTMENT OF CRIMINAL JUSTICE    INTERNAL USE ONLY", parent);
        footer->setGeometry(0, 872, 1600, 22);
        footer->setAlignment(Qt::AlignCenter);
        footer->setStyleSheet(MONO + "font-size:14px; letter-spacing:4px; color:#7ab8e0; background:transparent; font-weight:bold;");
    }
};


#endif
