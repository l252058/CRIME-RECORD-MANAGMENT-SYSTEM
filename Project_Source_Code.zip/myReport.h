#ifndef MYREPORTS_H
#define MYREPORTS_H

// =============================================================================
//  myReports.h
//  MyReports — shows ALL reports the logged-in user has submitted,
//              their current status, and any admin comment/response.
//
//  Standardized "Precision" UI refactor for consistency and clarity.
// =============================================================================

#include <QLabel>
#include <QPushButton>
#include <QResizeEvent>
#include <QScrollArea>
#include <QVBoxLayout>
#include <QWidget>

#include "common.h"
#include "file.h"
#include "submitReport.h"   // Brings in UserReportFile definition

class MyReports : public QWidget
{
private:

    QLabel      *img;
    QLabel      *pendingCount;
    QLabel      *approvedCount;
    QLabel      *rejectedCount;

    QWidget     *scrollContent;
    QVBoxLayout *scrollLayout;

    QString      loggedInEmail;

    // ── Build one styled report card ─────────────────────────────────────────

    QWidget *makeReportCard(const QStringList &r)
    {
        // r = { reportID, email, caseRef, subject, body, status, adminComment }
        QString reportID     = r.value(0, "—");
        QString caseRef      = r.value(2, "—");
        QString subject      = r.value(3, "—");
        QString body         = r.value(4, "—");
        QString status       = r.value(5, "Pending");
        QString adminComment = r.value(6, "").trimmed();

        // Colour-code by status
        QString statusColor = "#ffcc44"; // Pending
        if (status == "Approved") statusColor = "#44ff99";
        if (status == "Rejected") statusColor = "#ff6666";

        QWidget *card = new QWidget();
        card->setStyleSheet(
            "background    : rgba(0, 15, 45, 0.85);"
            "border        : 1px solid rgba(0, 200, 255, 0.25);"
            "border-radius : 10px;"
        );
        card->setMinimumHeight(200); // Increased from 160 to prevent clipping
        card->setFixedWidth(1130);

        // Status badge (top-right)
        QLabel *badge = new QLabel(status.toUpper(), card);
        badge->setGeometry(1000, 14, 120, 26);
        badge->setAlignment(Qt::AlignCenter);
        badge->setStyleSheet(
            MONO +
            "font-size     : 12px;"
            "font-weight   : bold;"
            "color         : #000000;"
            "background    : " + statusColor + ";"
            "border-radius : 4px;"
        );

        // Content Labels
        auto createRow = [&](const QString &label, const QString &val, int y, const QString &color, int size, bool bold) {
            QLabel *ql = new QLabel("  " + label + " : " + val, card);
            ql->setGeometry(14, y, 980, 24);
            ql->setStyleSheet(MONO + QString("font-size:%1px; color:%2; background:transparent; %3")
                .arg(size).arg(color).arg(bold ? "font-weight:bold;" : ""));
            return ql;
        };

        createRow("Report ID", reportID, 14, "#7ab8e0", 14, true);
        createRow("Case Ref",  caseRef,  44, "#00eaff", 16, true);
        createRow("Subject",   subject,  74, "#ffffff", 16, true);

        QString bodyShort = (body.length() > 140) ? body.left(140) + "..." : body;
        createRow("Details",   bodyShort, 104, "#c0dff5", 15, false);

        // Divider
        QLabel *div = new QLabel(card);
        div->setGeometry(14, 136, 1100, 1);
        div->setStyleSheet("background: rgba(0,200,255,0.15);");

        // Admin response
        QString responseText = adminComment.isEmpty() ? "Awaiting review..." : adminComment;
        QLabel *resLabel = createRow("Admin Response", responseText, 146, statusColor, 16, true);
        resLabel->setGeometry(14, 146, 1100, 44);
        resLabel->setWordWrap(true);
        resLabel->setAlignment(Qt::AlignTop | Qt::AlignLeft);

        return card;
    }

    // ── Data Loading ─────────────────────────────────────────────────────────

    void loadReports()
    {
        // Clear layout
        QLayoutItem *item;
        while ((item = scrollLayout->takeAt(0)) != nullptr) {
            if (item->widget()) item->widget()->deleteLater();
            delete item;
        }

        QList<QStringList> reports = UserReportFile::loadByEmail(loggedInEmail);

        // Update counts
        int pending = 0, approved = 0, rejected = 0;
        for (const QStringList &r : reports) {
            QString s = r.value(5).trimmed();
            if (s == "Pending")  pending++;
            if (s == "Approved") approved++;
            if (s == "Rejected") rejected++;
        }
        pendingCount->setText(QString::number(pending));
        approvedCount->setText(QString::number(approved));
        rejectedCount->setText(QString::number(rejected));

        if (reports.isEmpty()) {
            QLabel *empty = new QLabel("  You have not submitted any reports yet.");
            empty->setFixedHeight(60);
            empty->setStyleSheet(MONO + "font-size:16px; color:#7ab8e0; background:transparent;");
            scrollLayout->addWidget(empty);
        } else {
            for (int i = reports.size() - 1; i >= 0; i--) {
                scrollLayout->addWidget(makeReportCard(reports[i]));
            }
        }
        scrollLayout->addStretch();
    }

    // ── UI Components ────────────────────────────────────────────────────────

    QLabel *buildStatCard(int x, int y, const QString &color, const QString &caption)
    {
        QLabel *card = new QLabel(this);
        card->setGeometry(x, y, 220, 90);
        card->setStyleSheet(QString("background:rgba(0,20,50,0.85); border:1px solid %1; border-radius:10px;").arg(color));

        QLabel *num = new QLabel("0", this);
        num->setGeometry(x + 10, y + 10, 200, 44);
        num->setAlignment(Qt::AlignCenter);
        num->setStyleSheet(MONO + QString("font-size:32px; font-weight:900; color:%1; background:transparent;").arg(color));

        QLabel *cap = new QLabel(caption, this);
        cap->setGeometry(x + 10, y + 56, 200, 22);
        cap->setAlignment(Qt::AlignCenter);
        cap->setStyleSheet(MONO + "font-size:14px; letter-spacing:2px; color:#c0dff5; background:transparent; font-weight:bold;");

        return num;
    }

public:

    explicit MyReports(const QString &email = "") : QWidget(nullptr), loggedInEmail(email)
    {
        setWindowTitle("My Reports - CRIME RECORD MANAGEMENT SYSTEM");

        img = UI::setupBackground(this, "backgroundThree.png");

        // ── Sidebar ──────────────────────────────────────────────────────────
        new Card(0, 0, 320, 900, this);

        QLabel *sideTitle = new QLabel("CRIME RECORD\nMANAGEMENT\nSYSTEM", this);
        sideTitle->setGeometry(10, 10, 300, 120);
        sideTitle->setAlignment(Qt::AlignCenter);
        sideTitle->setWordWrap(true);
        sideTitle->setStyleSheet(MONO + "font-size:20px; color:#00eaff; background:transparent;");

        QLabel *sideDiv = new QLabel(this);
        sideDiv->setGeometry(30, 105, 260, 1);
        sideDiv->setStyleSheet("background: rgba(0,200,255,0.30);");

        QLabel *tag = new QLabel("[ MY REPORTS ]", this);
        tag->setGeometry(0, 115, 320, 30);
        tag->setAlignment(Qt::AlignCenter);
        tag->setStyleSheet(MONO + "font-size:18px; letter-spacing:4px; color:#ffcc44; background:transparent;");

        // Legend
        auto makeLeg = [&](const QString &txt, const QString &clr, int y) {
            QLabel *l = new QLabel(txt, this);
            l->setGeometry(30, y, 270, 24);
            l->setStyleSheet(MONO + QString("font-size:16px; letter-spacing:3px; color:%1; background:transparent;").arg(clr));
        };
        makeLeg("PENDING",  "#ffcc44", 170);
        makeLeg("APPROVED", "#44ff99", 200);
        makeLeg("REJECTED", "#ff6666", 230);

        QLabel *sideDiv2 = new QLabel(this);
        sideDiv2->setGeometry(30, 270, 260, 1);
        sideDiv2->setStyleSheet("background: rgba(0,200,255,0.20);");

        Button *refreshBtn = new Button("REFRESH LIST", 25, 300, 270, 44, this);
        BackButton *bb = new BackButton(25, 360, 270, 44, this);
        bb->raise();

        // ── Main Content ─────────────────────────────────────────────────────
        QLabel *pageTitle = new QLabel("MY SUBMITTED REPORTS", this);
        pageTitle->setGeometry(380, 40, 1180, 50);
        pageTitle->setStyleSheet(MONO + "font-size:40px; font-weight:900; letter-spacing:6px; color:#ffffff; background:transparent;");

        QLabel *pageSub = new QLabel("Track your case status and review administrator feedback below.", this);
        pageSub->setGeometry(380, 95, 1180, 22);
        pageSub->setStyleSheet(MONO + "font-size:18px; color:#7ab8e0; background:transparent;");

        QLabel *headerLine = new QLabel(this);
        headerLine->setGeometry(380, 125, 1180, 1);
        headerLine->setStyleSheet("background: rgba(0,200,255,0.25);");

        // Stat Cards
        pendingCount  = buildStatCard(380,  140, "#ffcc44", "PENDING");
        approvedCount = buildStatCard(850,  140, "#44ff99", "APPROVED");
        rejectedCount = buildStatCard(1300, 140, "#ff6666", "REJECTED");

        // Reports List Area
        QLabel *listTitle = new QLabel("REPORT HISTORY", this);
        listTitle->setGeometry(380, 252, 600, 28);
        listTitle->setStyleSheet(MONO + "font-size:18px; color:#00eaff; background:transparent;");

        QScrollArea *scroll = new QScrollArea(this);
        scroll->setGeometry(380, 288, 1180, 550);
        scroll->setWidgetResizable(true);
        scroll->setStyleSheet(
            "QScrollArea { background:rgba(3,12,35,0.95); border:1px solid rgba(0,200,255,0.30); border-radius:12px; }"
            "QScrollBar:vertical { background:rgba(0,15,45,0.80); width:8px; border-radius:4px; }"
            "QScrollBar::handle:vertical { background:rgba(0,200,255,0.40); border-radius:4px; }"
            "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0px; }"
        );

        scrollContent = new QWidget();
        scrollContent->setStyleSheet("background:transparent;");
        scrollLayout = new QVBoxLayout(scrollContent);
        scrollLayout->setContentsMargins(15, 15, 15, 15);
        scrollLayout->setSpacing(12);
        scroll->setWidget(scrollContent);

        // Connections
        connect(refreshBtn, &QPushButton::clicked, this, [=]() {
            FileHandler::appendLog("USER", "Refreshed My Reports");
            loadReports();
        });

        loadReports(); // Initial load
    }

    void setEmail(const QString &email) { loggedInEmail = email; loadReports(); }
    void resizeEvent(QResizeEvent *) override { img->resize(size()); }
};

#endif // MYREPORTS_H