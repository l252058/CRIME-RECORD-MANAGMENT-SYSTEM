#ifndef ADMINMENU_H
#define ADMINMENU_H

#include <QWidget>
#include <QLabel>
#include <QPixmap>
#include <QPushButton>

#include "common.h"
#include "file.h"
#include "crimeRecords.h"
#include "crimeStatus.h"
#include "court.h"
#include "reports.h"
#include "officer.h"
#include "activityLog.h"
#include "adminReport.h"
#include "logout.h"

class Admin : public QWidget
{
private:
    QLabel *img;

    QPushButton *button[9];

    QWidget *previousWindow;

public:
    Admin(QWidget *prev = nullptr) : previousWindow(prev)
    {
        setWindowTitle("ADMIN MENU - CRIME RECORD MANAGEMENT SYSTEM");

        img = new QLabel(this);
        img->setGeometry(0, 0, 1600, 900);
        img->setPixmap(loadPixmap("backgroundThree.png"));
        img->setScaledContents(true);
        img->lower();
        img->show();

        new Card(0, 0, 320, 1000, this);

        QLabel* sidebarTitle = new QLabel("CRIME RECORD\nMANAGEMENT\nSYSTEM", this);
        sidebarTitle->setGeometry(10, 10, 300, 120);
        sidebarTitle->setAlignment(Qt::AlignCenter);
        sidebarTitle->setWordWrap(true);
        sidebarTitle->setStyleSheet
        (
            MONO +
            "font-size:20px;"
            "font-weight:bold;"
            "letter-spacing:1px;"
            "color:#00eaff;"
            "background:transparent;"
        );

        QLabel* sidebarLine = new QLabel(this);
        sidebarLine->setGeometry(30, 110, 260, 1);
        sidebarLine->setStyleSheet("background:rgba(0, 200, 255, 0.30);");

        QLabel* sidebarTag = new QLabel("[ ADMIN ACCESS ]", this);
        sidebarTag->setGeometry(0, 120, 320, 30);
        sidebarTag->setAlignment(Qt::AlignCenter);
        sidebarTag->setStyleSheet
        (
            MONO +
            "font-size:18px;"
            "letter-spacing:4px;"
            "color:#ffcc44;"
            "font-weight:bold;"
            "background:transparent;"
        );

        QLabel* pageTitle = new QLabel("ADMIN DASHBOARD", this);
        pageTitle->setGeometry(380, 40, 1180, 50);
        pageTitle->setStyleSheet
        (
            MONO +
            "font-size:40px;"
            "font-weight:900;"
            "letter-spacing:6px;"
            "color:#ffffff;"
            "background:transparent;"
        );

        QLabel* pageSub = new QLabel("Full system control — select an option from the menu", this);
        pageSub->setGeometry(380, 95, 1180, 22);
        pageSub->setStyleSheet
        (
            MONO +
            "font-size:18px;"
            "font-weight:bold;"
            "color:#7ab8e0;"
            "background:transparent;"
        );

        QLabel* headerLine = new QLabel(this);
        headerLine->setGeometry(380, 125, 1180, 1);
        headerLine->setStyleSheet("background:rgba(0, 200, 255, 0.25);");

        QLabel* footer = new QLabel("DEPARTMENT OF CRIMINAL JUSTICE    INTERNAL USE ONLY", this);
        footer->setGeometry(0, 872, 1600, 22);
        footer->setAlignment(Qt::AlignCenter);
        footer->setStyleSheet
        (
            MONO +
            "font-size:14px;"
            "letter-spacing:4px;"
            "color:#7ab8e0;"
            "background:transparent;"
            "font-weight:bold;"
        );

        QLabel *welcomeText = new QLabel("WELCOME,  ADMINISTRATOR", this);
        welcomeText->setGeometry(380, 250, 1180, 40);
        welcomeText->setAlignment(Qt::AlignCenter);
        welcomeText->setStyleSheet
        (
            MONO +
            "font-size : 32px;"
            "font-weight : bold;"
            "letter-spacing : 6px;"
            "color : #ffcc44;"
            "background : transparent;"
        );

        QLabel *welcomeSub = new QLabel("You have full access to manage records, officers, reports, and users.", this);
        welcomeSub->setGeometry(380, 300, 1180, 24);
        welcomeSub->setAlignment(Qt::AlignCenter);
        welcomeSub->setStyleSheet
        (
            MONO +
            "font-size : 16px;"
            "color : #c0dff5;"
            "background : transparent;"
            "font-weight: bold;"
        );

        const char* menuItems[] = {
            "Manage Records", "Manage Officers", "Case Status", "Court Proceedings",
            "Reports & Analytics", "User Review", "Activity Logs"
        };

        for (int i = 0; i < 7; i++)
        {
            button[i] = new QPushButton(menuItems[i], this);
            button[i]->setGeometry(25, 170 + i * 60, 270, 40);
            button[i]->setCursor(Qt::PointingHandCursor);
            button[i]->setStyleSheet
            (
                "QPushButton"
                "{"
                    "background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #005577, stop:1 #002233);"
                    "color: #00eaff;"
                    "border: 1px solid #00eaff;"
                    "border-radius: 6px;"
                    "font-family: 'Courier New', monospace;"
                    "font-weight: bold;"
                    "font-size: 14px;"
                    "letter-spacing: 1px;"
                "}"
                "QPushButton:hover"
                "{"
                    "background: #00eaff;"
                    "color: #001122;"
                "}"
                "QPushButton:pressed"
                "{"
                    "background: #00ccff;"
                    "padding-top: 2px;"
                "}"
            );
        }

        button[7] = new QPushButton("  ←  RETURN", this);
        button[7]->setGeometry(25, 590, 270, 40);
        button[7]->setCursor(Qt::PointingHandCursor);
        button[7]->setStyleSheet
        (
            "QPushButton"
            "{"
                "background: rgba(255, 255, 255, 0.05);"
                "color: #7ab8e0;"
                "border: 1px solid rgba(122, 184, 224, 0.3);"
                "border-radius: 6px;"
                "font-family: 'Courier New', monospace;"
                "font-weight: bold;"
                "font-size: 14px;"
            "}"
            "QPushButton:hover"
            "{"
                "background: rgba(255, 255, 255, 0.1);"
                "color: white;"
            "}"
        );

        button[8] = new QPushButton("LOGOUT", this);
        button[8]->setGeometry(25, 650, 270, 40);
        button[8]->setCursor(Qt::PointingHandCursor);
        button[8]->setStyleSheet
        (
            "QPushButton"
            "{"
                "background: #ff4444;"
                "color: white;"
                "border-radius: 6px;"
                "font-family: 'Courier New', monospace;"
                "font-weight: bold;"
                "font-size: 14px;"
            "}"
            "QPushButton:hover"
            "{"
                "background: #ff2222;"
            "}"
        );

        connect(button[0], &QPushButton::clicked, this, [=]()
            {
                FileHandler::appendLog("ADMIN", "Opened Manage Records");
                CrimeRecordPage *page = new CrimeRecordPage(true);
                page->setAttribute(Qt::WA_DeleteOnClose);
                page->showMaximized();
            }
        );

        connect(button[1], &QPushButton::clicked, this, [=]()
            {
                FileHandler::appendLog("ADMIN", "Opened Manage Officers");
                Officers *page = new Officers(true);
                page->setAttribute(Qt::WA_DeleteOnClose);
                page->showMaximized();
            }
        );

        connect(button[2], &QPushButton::clicked, this, [=]()
            {
                FileHandler::appendLog("ADMIN", "Opened Case Status");
                CaseStatusPage *page = new CaseStatusPage(true);
                page->setAttribute(Qt::WA_DeleteOnClose);
                page->showMaximized();
            }
        );

        connect(button[3], &QPushButton::clicked, this, [=]()
            {
                FileHandler::appendLog("ADMIN", "Opened Court Proceedings");
                CourtProceedings *page = new CourtProceedings(true);
                page->setAttribute(Qt::WA_DeleteOnClose);
                page->showMaximized();
            }
        );

        connect(button[4], &QPushButton::clicked, this, [=]()
            {
                FileHandler::appendLog("ADMIN", "Opened Reports & Analytics");
                Reports *page = new Reports();
                page->setAttribute(Qt::WA_DeleteOnClose);
                page->showMaximized();
            }
        );

        connect(button[5], &QPushButton::clicked, this, [=]()
            {
                FileHandler::appendLog("ADMIN", "Opened User Review");
                AdminReports *page = new AdminReports();
                page->setAttribute(Qt::WA_DeleteOnClose);
                page->showMaximized();
            }
        );

        connect(button[6], &QPushButton::clicked, this, [=]()
            {
                FileHandler::appendLog("ADMIN", "Opened Activity Logs");
                ActivityLogs *page = new ActivityLogs();
                page->setAttribute(Qt::WA_DeleteOnClose);
                page->showMaximized();
            }
        );

        connect(button[7], &QPushButton::clicked, this, [=]()
            {
                if (previousWindow)
                {
                    previousWindow->showMaximized();
                }
                this->close();
            }
        );

        connect(button[8], &QPushButton::clicked, this, [=]()
            {
                LogoutDialog *logout = new LogoutDialog(this);
                logout->showMaximized();
            }
        );
    }

    void resizeEvent(QResizeEvent * event) override
    {
        img->resize(event->size());
    }
};

#endif