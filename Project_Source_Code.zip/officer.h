#ifndef OFFICERMENU_H
#define OFFICERMENU_H

#include <QWidget>
#include <QLabel>
#include <QPixmap>
#include <QPushButton>
#include <QScrollArea>
#include <QStackedWidget>
#include <QResizeEvent>
#include <QMessageBox>
#include <QVBoxLayout>
#include <QVector>
#include <functional>

#include "common.h"
#include "file.h"

static QString formatOfficerRecord(const QStringList &parts)
{
    if (parts.size() < 4) return "";
    QString assigned = "Unassigned";
    if (parts.size() >= 5 && !parts[4].trimmed().isEmpty()) assigned = parts[4].trimmed();
    
    return QString("  Officer ID  : %1\n"
                   "  Name        : %2\n"
                   "  Rank        : %3\n"
                   "  Badge       : %4\n"
                   "  Assigned To : %5\n"
                   "  --------------------------------------------------\n")
           .arg(parts[0]).arg(parts[1]).arg(parts[2]).arg(parts[3]).arg(assigned);
}

// =============================================================================
//  Shared Stylesheet Helpers
// =============================================================================

inline static QString officerFieldLabelStyle()
{
    return
        MONO +
        "font-size   : 20px;"
        "font-weight : bold;"
        "color       : #a0d8f0;"
        "background  : transparent;";
}

inline static QString officerScrollAreaStyle()
{
    return
        "background    : rgba(0, 8, 24, 0.98);"
        "border        : 1px solid rgba(0, 200, 255, 0.35);"
        "border-radius : 12px;";
}

inline static QString officerResultLabelStyle()
{
    return
        "background  : transparent;"
        "color       : #c0dff5;"
        "font-family : 'Courier New', monospace;"
        "font-weight : bold;"
        "font-size   : 16px;"
        "padding     : 14px;";
}

// =============================================================================
//  ADD OFFICER PANEL
// =============================================================================

class AddOfficer : public QWidget
{
    Q_OBJECT

private:

    Box    * officerIDBox;
    Box    * nameBox;
    Box    * rankBox;
    Box    * badgeBox;
    QLabel * feedback;

    void setFeedback(const QString & message, const QString & color)
    {
        feedback->setStyleSheet
        (
            MONO +
            QString
            (
                "font-size  : 16px;"
                "font-weight : bold;"
                "color      : %1;"
                "background : transparent;"
            ).arg(color)
        );

        feedback->setText("  " + message);
    }

    void clearFields()
    {
        officerIDBox->clear();
        nameBox->clear();
        rankBox->clear();
        badgeBox->clear();
        feedback->setText("");
    }

public:

    explicit AddOfficer(QWidget * parent = nullptr) : QWidget(parent)
    {
        new Card(0, 0, 760, 500, this);

        QLabel * heading = new QLabel("ADD NEW OFFICER", this);
        
        heading->setGeometry(20, 18, 720, 28);
        
        heading->setStyleSheet
        (
            MONO +
            "font-size   : 18px;"
            "font-weight : bold;"
            "color       : #00eaff;"
            "background  : transparent;"
        );

        QLabel * divider = new QLabel(this);
        
        divider->setGeometry(20, 52, 720, 1);
        
        divider->setStyleSheet("background : rgba(0, 200, 255, 0.20);");

        QLabel * idLabel = new QLabel("Officer ID  *", this);
        
        idLabel->setGeometry(20, 68, 300, 24);
        
        idLabel->setStyleSheet(officerFieldLabelStyle());

        officerIDBox = new Box(20, 94, 720, 38, "e.g.  OFF-001", this);

        QLabel * nameLabel = new QLabel("Full Name  *", this);
        
        nameLabel->setGeometry(20, 148, 300, 24);
        
        nameLabel->setStyleSheet(officerFieldLabelStyle());

        nameBox = new Box(20, 174, 720, 38, "e.g.  Ali Hassan", this);

        QLabel * rankLabel = new QLabel("Rank  *", this);
        
        rankLabel->setGeometry(20, 228, 300, 24);
        
        rankLabel->setStyleSheet(officerFieldLabelStyle());

        rankBox = new Box(20, 254, 720, 38, "e.g.  Inspector", this);

        QLabel * badgeLabel = new QLabel("Badge Number  *", this);
        
        badgeLabel->setGeometry(20, 308, 300, 24);
        
        badgeLabel->setStyleSheet(officerFieldLabelStyle());

        badgeBox = new Box(20, 334, 720, 38, "e.g.  PKP-2201", this);

        feedback = new QLabel("", this);
        
        feedback->setGeometry(20, 388, 720, 22);
        
        feedback->setStyleSheet
        (
            MONO +
            "font-size  : 16px;"
            "font-weight: bold;"
            "color      : #00eaff;"
            "background : transparent;"
        );

        Button * saveButton = new Button("SAVE", 20, 420, 200, 44, this);
        
        ClearButton * clearButton = new ClearButton("CLEAR", 620, 420, 120, 44, this);

        QObject::connect(clearButton, &QPushButton::clicked, [this]()
        { 
            clearFields(); 
        });

        QObject::connect(saveButton, &QPushButton::clicked, [this]()
        {
            QString id    = officerIDBox->text().trimmed();
            QString name  = nameBox->text().trimmed();
            QString rank  = rankBox->text().trimmed();
            QString badge = badgeBox->text().trimmed();

            if (id.isEmpty() || name.isEmpty() || rank.isEmpty() || badge.isEmpty())
            {
                setFeedback("All fields are required.", "#ff6666");
                return;
            }

            if (FileHandler::officerIDExists(id))
            {
                setFeedback("Officer ID already exists. Use a different ID.", "#ff6666");
                return;
            }

            FileHandler::saveOfficer(id, name, rank, badge);
            
            FileHandler::appendLog("ADMIN", QString("Officer added — ID: %1  Name: %2  Rank: %3").arg(id).arg(name).arg(rank));
            
            setFeedback(QString("Officer %1 (%2) saved successfully!").arg(name).arg(id), "#44ff99");
            
            clearFields();
            
            emit officerAdded();
        });
    }

signals:
    void officerAdded();
};

// =============================================================================
//  ASSIGN / REASSIGN OFFICER PANEL
// =============================================================================

class AssignOfficer : public QWidget
{
    Q_OBJECT

private:

    Box    * officerIDBox;
    Box    * caseIDBox;
    QLabel * feedback;
    QLabel * currentAssignmentLabel;
    bool     officerLoaded = false;

    void setFeedback(const QString & message, const QString & color)
    {
        feedback->setStyleSheet(MONO + QString("font-size:16px; font-weight:bold; color:%1; background:transparent;").arg(color));
        
        feedback->setText("  " + message);
    }

    void clearFields()
    {
        officerIDBox->clear();
        caseIDBox->clear();
        feedback->setText("");
        officerLoaded = false;
        
        currentAssignmentLabel->setText("  Current assignment will appear here after loading.");
    }

public:

    explicit AssignOfficer(QWidget * parent = nullptr) : QWidget(parent)
    {
        new Card(0, 0, 760, 450, this);

        QLabel * heading = new QLabel("ASSIGN / REASSIGN OFFICER TO CASE", this);
        
        heading->setGeometry(20, 18, 720, 28);
        
        heading->setStyleSheet(MONO + "font-size:18px; font-weight:bold; color:#00eaff; background:transparent;");

        QLabel * divider = new QLabel(this);
        
        divider->setGeometry(20, 52, 720, 1);
        
        divider->setStyleSheet("background:rgba(0,200,255,0.20);");

        QLabel * officerLabel = new QLabel("Officer ID  *", this);
        
        officerLabel->setGeometry(20, 68, 300, 24);
        
        officerLabel->setStyleSheet(officerFieldLabelStyle());

        officerIDBox = new Box(20, 94, 540, 38, "e.g.  OFF-001", this);

        Button * loadButton = new Button("Load", 572, 94, 148, 38, this);

        currentAssignmentLabel = new QLabel("  Current assignment will appear here after loading.", this);
        
        currentAssignmentLabel->setGeometry(20, 144, 720, 22);
        
        currentAssignmentLabel->setStyleSheet(MONO + "font-size:16px; font-weight:bold; color:#ffcc44; background:transparent;");

        QLabel * caseLabel = new QLabel("New Case ID  *", this);
        
        caseLabel->setGeometry(20, 180, 300, 24);
        
        caseLabel->setStyleSheet(officerFieldLabelStyle());

        caseIDBox = new Box(20, 206, 720, 38, "e.g.  CR-001", this);

        QLabel * note = new QLabel(
            "  Load an Officer ID first to see their current assignment.\n"
            "  Enter a new Case ID and click Assign / Reassign to update.", this);
        
        note->setGeometry(20, 260, 720, 40);
        
        note->setStyleSheet(MONO + "font-size:16px; font-weight:bold; color:#7ab8e0; background:transparent;");

        feedback = new QLabel("", this);
        
        feedback->setGeometry(20, 316, 720, 22);
        
        feedback->setStyleSheet(MONO + "font-size:16px; font-weight:bold; color:#00eaff; background:transparent;");

        Button * assignButton = new Button("ASSIGN", 20, 352, 240, 44, this);

        QPushButton * reassignButton = new QPushButton("REASSIGN", this);
        
        reassignButton->setGeometry(500, 352, 240, 44);
        reassignButton->setCursor(Qt::PointingHandCursor);
        
        reassignButton->setStyleSheet(
            "QPushButton"
            "{"
            "    background     : rgba(80, 0, 0, 0.70);"
            "    color          : #ffffff;"
            "    font-family    : 'Courier New', monospace;"
            "    font-size      : 18px;"
            "    font-weight    : bold;"
            "    letter-spacing : 3px;"
            "    border         : 1px solid rgba(255, 80, 80, 0.45);"
            "    border-radius  : 6px;"
            "    text-align     : center;"
            "}"
            "QPushButton:hover  { background:rgba(160,0,0,0.80); color:#ffffff; border:1px solid #ff4444; }"
            "QPushButton:pressed{ background:#5a0000; }"
        );

        QObject::connect(loadButton, &QPushButton::clicked, [this]()
        {
            QString id = officerIDBox->text().trimmed();
            
            if (id.isEmpty()) 
            { 
                setFeedback("Enter an Officer ID to load.", "#ff6666"); 
                return; 
            }
            
            if (!FileHandler::officerIDExists(id))
            {
                setFeedback("Officer ID not found.", "#ff6666");
                currentAssignmentLabel->setText("  Officer not found.");
                officerLoaded = false; 
                return;
            }
            
            QStringList parts = FileHandler::loadOfficer(id);
            
            if (parts.size() < 4)
            {
                setFeedback("Officer record is incomplete or corrupted.", "#ff6666");
                officerLoaded = false; 
                return;
            }
            
            QString current = "Unassigned";
            
            if (parts.size() >= 5)
            {
                if (!parts[4].trimmed().isEmpty())
                {
                    current = parts[4].trimmed();
                }
            }
            
            officerLoaded = true;
            
            currentAssignmentLabel->setText(QString("  Officer: %1   |   Currently assigned to: %2").arg(id).arg(current));
            
            setFeedback("Officer loaded. Enter a new Case ID to assign.", "#44ff99");
        });

        auto doAssign = [this](const QString &action)
        {
            QString officerID = officerIDBox->text().trimmed();
            QString caseID    = caseIDBox->text().trimmed();
            
            if (!officerLoaded) 
            { 
                setFeedback("Load a valid Officer ID first.", "#ff6666"); 
                return; 
            }
            
            if (officerID.isEmpty() || caseID.isEmpty())
            { 
                setFeedback("Officer ID and Case ID are both required.", "#ff6666"); 
                return; 
            }
            
            if (!FileHandler::officerIDExists(officerID))
            { 
                setFeedback("Officer ID not found.", "#ff6666"); 
                return; 
            }
            
            if (!FileHandler::caseIDExists(caseID))
            { 
                setFeedback("Case ID not found in crime records.", "#ff6666"); 
                return; 
            }

            FileHandler::assignOfficerToCase(officerID, caseID);
            
            FileHandler::appendLog("ADMIN", QString("Officer %1 — Officer ID: %2 → Case ID: %3").arg(action).arg(officerID).arg(caseID));
            
            setFeedback(QString("Officer %1 successfully %2 to case %3.").arg(officerID).arg(action.toLower() + "ed").arg(caseID), "#44ff99");
            
            currentAssignmentLabel->setText(QString("  Officer: %1   |   Now assigned to: %2").arg(officerID).arg(caseID));
            
            emit officerAssigned();
        };

        QObject::connect(assignButton, &QPushButton::clicked, [doAssign]()
        { 
            doAssign("Assign"); 
        });
        
        QObject::connect(reassignButton, &QPushButton::clicked, [doAssign]()
        { 
            doAssign("Reassign"); 
        });
    }

signals:
    void officerAssigned();
};

// =============================================================================
//  VIEW OFFICERS PANEL
// =============================================================================

class ViewOfficers : public QWidget
{
private:

    Button      * refreshButton;
    QLabel      * resultLabel;
    QScrollArea * scrollArea;
    bool          isAdminRole;

public:

    explicit ViewOfficers(bool adminRole, QWidget * parent = nullptr)
        : QWidget(parent)
        , isAdminRole(adminRole)
    {
        QLabel * heading = new QLabel("ALL OFFICERS", this);
        
        heading->setGeometry(0, 8, 900, 30);
        
        heading->setStyleSheet(MONO + "font-size:18px; font-weight:bold; color:#00eaff; background:transparent;");

        refreshButton = new Button("REFRESH", 1005, 6, 140, 34, this);

        scrollArea = new QScrollArea(this);
        
        scrollArea->setGeometry(0, 50, 1150, 480);
        scrollArea->setStyleSheet(officerScrollAreaStyle());
        scrollArea->setWidgetResizable(true);
        scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);

        resultLabel = new QLabel();
        
        resultLabel->setAlignment(Qt::AlignTop | Qt::AlignLeft);
        resultLabel->setWordWrap(true);
        resultLabel->setStyleSheet(officerResultLabelStyle());
        resultLabel->setText("  Click REFRESH to load all officers.");

        scrollArea->setWidget(resultLabel);

        QObject::connect(refreshButton, &QPushButton::clicked, [this]()
        { 
            loadAndDisplay(); 
        });
    }

    void loadAndDisplay()
    {
        QStringList records = FileHandler::loadOfficers();

        if (records.isEmpty()) 
        { 
            resultLabel->setText("  No officers found."); 
            return; 
        }

        QString display;
        
        for (const QString & line : records)
        {
            display += formatOfficerRecord(line.split("\t"));
        }
        
        resultLabel->setText(display);

        QString role = "USER";
        
        if (isAdminRole)
        {
            role = "ADMIN";
        }
        
        FileHandler::appendLog(role, "Viewed officer list.");
    }
};

// =============================================================================
//  OFFICERS PAGE
// =============================================================================

class Officers : public QWidget
{
private:

    QLabel         * backgroundImage;
    QStackedWidget * stack;
    ViewOfficers   * viewPage;
    AddOfficer     * addPage;
    AssignOfficer  * assignPage;
    Button         * viewBtn;
    Button         * addBtn;
    Button         * assignBtn;
    StatCard       * assignedNumber;
    StatCard       * unassignedNumber;
    StatCard       * totalNumber;


    void refreshCounts()
    {
        int assigned   = FileHandler::countAssignedOfficers();
        int unassigned = FileHandler::countUnassignedOfficers();
        
        assignedNumber->setValue(assigned);
        unassignedNumber->setValue(unassigned);
        totalNumber->setValue(assigned + unassigned);
    }

    void buildLegend(const QString & text, const QString & color, int y)
    {
        QLabel * legend = new QLabel(text, this);
        
        legend->setGeometry(30, y, 270, 24);
        
        legend->setStyleSheet(MONO + QString("font-size:16px; letter-spacing:4px; font-weight:bold; color:%1; background:transparent;").arg(color));
    }

public:

    explicit Officers(bool isAdmin) : QWidget(nullptr)
    {
        setWindowTitle("Officer Management — CRIME RECORD MANAGEMENT SYSTEM");

        backgroundImage = UI::setupBackground(this, "backgroundThree.png");

        new Card(0, 0, 320, 900, this);

        QLabel * sideTitle = new QLabel("CRIME RECORD\nMANAGEMENT\nSYSTEM", this);
        sideTitle->setGeometry(10, 10, 300, 120);
        sideTitle->setAlignment(Qt::AlignCenter);
        sideTitle->setWordWrap(true);
        sideTitle->setStyleSheet(MONO + "font-size:20px; font-weight:bold; letter-spacing:1px; color:#00eaff; background:transparent;");

        QLabel * dividerOne = new QLabel(this);
        
        dividerOne->setGeometry(30, 100, 260, 1);
        
        dividerOne->setStyleSheet("background:rgba(0,200,255,0.30);");

        QLabel * tag = new QLabel("[ OFFICERS ]", this);
        
        tag->setGeometry(0, 110, 320, 30);
        tag->setAlignment(Qt::AlignCenter);
        
        tag->setStyleSheet(MONO + "font-size:18px; letter-spacing:4px; color:#ffcc44; font-weight:bold; background:transparent;");

        buildLegend("ASSIGNED",   "#44ff99", 172);
        buildLegend("UNASSIGNED", "#ff6666", 200);
        buildLegend("TOTAL",      "#c0dff5", 228);

        QLabel * dividerTwo = new QLabel(this);
        
        dividerTwo->setGeometry(30, 264, 260, 1);
        
        dividerTwo->setStyleSheet("background:rgba(0,200,255,0.20);");

        viewBtn = new Button("View Officers", 25, 300, 270, 40, this);

        addBtn    = nullptr;
        assignBtn = nullptr;

        if (isAdmin)
        {
            addBtn = new Button("Add Officer", 25, 360, 270, 40, this);

            assignBtn = new Button("Assign / Reassign", 25, 420, 270, 40, this);
        }

        BackButton *bb = new BackButton(25, isAdmin ? 480 : 360, 270, 44, this);
        bb->raise();

        QObject::connect(bb, &QPushButton::clicked, [this]() { this->close(); });

        QLabel * pageTitle = new QLabel("OFFICER MANAGEMENT", this);
        
        pageTitle->setGeometry(380, 40, 1180, 50);
        
        pageTitle->setStyleSheet(MONO + "font-size:36px; font-weight:900; letter-spacing:6px; color:#ffffff; background:transparent;");

        QLabel * pageSubtitle = new QLabel("Manage officers and assign them to cases", this);
        
        pageSubtitle->setGeometry(380, 95, 1180, 22);
        
        pageSubtitle->setStyleSheet(MONO + "font-size:18px; font-weight:bold; color:#7ab8e0; background:transparent;");

        assignedNumber   = new StatCard(380,  140, "#44ff99", "ASSIGNED",   this);
        unassignedNumber = new StatCard(850,  140, "#ff6666", "UNASSIGNED", this);
        totalNumber      = new StatCard(1300, 140, "#00eaff", "TOTAL",      this);

        QLabel * footer = new QLabel("DEPARTMENT OF CRIMINAL JUSTICE    |    INTERNAL USE ONLY", this);
        
        footer->setGeometry(0, 872, 1600, 18);
        footer->setAlignment(Qt::AlignCenter);
        
        footer->setStyleSheet(MONO + "font-size:14px; letter-spacing:4px; color:#7ab8e0; background:transparent; font-weight:bold;");

        stack = new QStackedWidget(this);
        
        stack->setGeometry(380, 250, 1150, 580);
        stack->setStyleSheet("background:transparent;");

        viewPage   = new ViewOfficers(isAdmin, stack);
        addPage    = new AddOfficer(stack);
        assignPage = new AssignOfficer(stack);

        stack->addWidget(viewPage);
        stack->addWidget(addPage);
        stack->addWidget(assignPage);
        stack->setCurrentIndex(0);

        refreshCounts();

        QObject::connect(viewBtn, &QPushButton::clicked, [this]()
        {
            refreshCounts();
            viewPage->loadAndDisplay();
            stack->setCurrentIndex(0);
        });

        if (isAdmin)
        {
            if (addBtn != nullptr)
            {
                if (assignBtn != nullptr)
                {
                    QObject::connect(addBtn, &QPushButton::clicked, [this]()
                    { 
                        refreshCounts(); 
                        stack->setCurrentIndex(1); 
                    });

                    QObject::connect(assignBtn, &QPushButton::clicked, [this]()
                    { 
                        refreshCounts(); 
                        stack->setCurrentIndex(2); 
                    });

                    QObject::connect(addPage, &AddOfficer::officerAdded, [this]()
                    { 
                        refreshCounts(); 
                    });

                    QObject::connect(assignPage, &AssignOfficer::officerAssigned, [this]()
                    { 
                        refreshCounts(); 
                    });
                }
            }
        }
    }

    void resizeEvent(QResizeEvent * event) override
    {
        backgroundImage->resize(event->size());
    }
};

#endif // OFFICERMENU_H