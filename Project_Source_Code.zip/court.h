#ifndef COURT_H
#define COURT_H

#include <QWidget>
#include <QLabel>
#include <QPixmap>
#include <QScrollArea>
#include <QPushButton>

#include "common.h"
#include "file.h"

static QString formatCourtRecord(const QStringList &parts)
{
    if (parts.size() < 4) return "";
    return "  Case ID  : " + parts[0].trimmed() + "\n" +
           "  Accused  : " + parts[1].trimmed() + "\n" +
           "  Crime    : " + parts[2].trimmed() + "\n" +
           "  Status   : " + parts[3].trimmed() + "\n" +
           "  --------------------------------------------------\n";
}

// =============================================================================
//  Shared Stylesheet Helpers
// =============================================================================

inline static QString courtFieldLabel()
{
    return MONO + 
           "font-size   : 20px; "
           "font-weight : bold; "
           "color       : #a0d8f0; "
           "background  : transparent;";
}

// =============================================================================
//  VIEW COURT PANEL
// =============================================================================

class ViewCourt : public QWidget
{
private:

    RecordDisplay * resultDisplay;

    void load()
    {
        QStringList records = FileHandler::loadCourt();

        if (records.isEmpty())
        {
            resultDisplay->setText("  No court proceedings found.");
            return;
        }

        QString display;

        for (const QString & line : records)
        {
            display += formatCourtRecord(line.split("\t"));
        }

        resultDisplay->setText(display);
        
        FileHandler::appendLog("USER", "Viewed all court proceedings");
    }

public:

    explicit ViewCourt(QWidget * parent = nullptr) 
        : QWidget(parent)
    {
        QLabel * heading = new QLabel("ALL COURT PROCEEDINGS", this);
        
        heading->setGeometry(0, 8, 900, 30);
        
        heading->setStyleSheet
        (
            MONO +
            "font-size   : 18px; "
            "font-weight : bold; "
            "color       : #00eaff; "
            "background  : transparent;"
        );

        Button * refreshButton = new Button("REFRESH", 1005, 6, 140, 34, this);

        resultDisplay = new RecordDisplay(0, 50, 1150, 485, this, "  No court proceedings found.");

        QObject::connect(refreshButton, &QPushButton::clicked, [this]() 
        { 
            load(); 
        });
    }

    void activate() 
    { 
        load(); 
    }
};

// =============================================================================
//  FILTER COURT PANEL
// =============================================================================

class FilterCourt : public QWidget
{
private:

    RecordDisplay * filterResult;

    void filterBy(const QString & status)
    {
        QStringList records = FileHandler::loadCourt();
        QString     display;

        for (const QString & line : records)
        {
            QStringList p = line.split("\t");

            if (p.size() >= 4)
            {
                if (p[3].trimmed().toLower() == status.toLower())
                {
                    display += formatCourtRecord(p);
                }
            }
        }

        if (display.isEmpty())
        {
            filterResult->setText("  No " + status + " proceedings found.");
        }
        else
        {
            filterResult->setText(display);
        }

        FileHandler::appendLog("USER", "Filtered court proceedings by: " + status);
    }

public:

    explicit FilterCourt(QWidget * parent = nullptr) 
        : QWidget(parent)
    {
        new Card(170, 0, 800, 128, this);

        QLabel * heading = new QLabel("FILTER BY COURT STATUS", this);
        
        heading->setGeometry(190, 18, 760, 28);
        
        heading->setStyleSheet
        (
            MONO +
            "font-size   : 18px; "
            "font-weight : bold; "
            "color       : #00eaff; "
            "background  : transparent;"
        );

        QLabel * divider = new QLabel(this);
        
        divider->setGeometry(190, 52, 760, 1);
        
        divider->setStyleSheet("background : rgba(0, 200, 255, 0.20);");

        QPushButton * ongoingBtn = new QPushButton("ONGOING", this);
        
        ongoingBtn->setGeometry(190, 68, 250, 52);
        
        ongoingBtn->setCursor(Qt::PointingHandCursor);
        
        ongoingBtn->setStyleSheet
        (
            "QPushButton"
            "{"
            "    background    : rgba(0, 8, 24, 0.98); "
            "    color         : #00eaff; "
            "    font-family   : 'Courier New', monospace; "
            "    font-size     : 16px; "
            "    font-weight   : bold; "
            "    border        : 1px solid #00eaff; "
            "    border-radius : 8px; "
            "    text-align    : center; "
            "}"
            "QPushButton:hover { background : #00eaff; color : #000000; }"
        );

        QPushButton * onHoldBtn = new QPushButton("ON HOLD", this);
        
        onHoldBtn->setGeometry(445, 68, 250, 52);
        
        onHoldBtn->setCursor(Qt::PointingHandCursor);
        
        onHoldBtn->setStyleSheet
        (
            "QPushButton"
            "{"
            "    background    : rgba(0, 8, 24, 0.98); "
            "    color         : #ffcc44; "
            "    font-family   : 'Courier New', monospace; "
            "    font-size     : 16px; "
            "    font-weight   : bold; "
            "    border        : 1px solid #ffcc44; "
            "    border-radius : 8px; "
            "    text-align    : center; "
            "}"
            "QPushButton:hover { background : #ffcc44; color : #000000; }"
        );

        QPushButton * verdictBtn = new QPushButton("VERDICT REACHED", this);
        
        verdictBtn->setGeometry(700, 68, 250, 52);
        
        verdictBtn->setCursor(Qt::PointingHandCursor);
        
        verdictBtn->setStyleSheet
        (
            "QPushButton"
            "{"
            "    background    : rgba(0, 8, 24, 0.98); "
            "    color         : #44ff99; "
            "    font-family   : 'Courier New', monospace; "
            "    font-size     : 16px; "
            "    font-weight   : bold; "
            "    border        : 1px solid #44ff99; "
            "    border-radius : 8px; "
            "    text-align    : center; "
            "}"
            "QPushButton:hover { background : #44ff99; color : #000000; }"
        );

        filterResult = new RecordDisplay(0, 160, 1150, 385, this, "  Press a button above to filter proceedings.");

        QObject::connect(ongoingBtn, &QPushButton::clicked, [this]() 
        { 
            filterBy("Ongoing"); 
        });

        QObject::connect(onHoldBtn, &QPushButton::clicked, [this]() 
        { 
            filterBy("On Hold"); 
        });

        QObject::connect(verdictBtn, &QPushButton::clicked, [this]() 
        { 
            filterBy("Verdict Reached"); 
        });
    }

    void activate() 
    { 
        filterBy("Ongoing"); 
    }
};

// =============================================================================
//  UPDATE COURT STATUS PANEL
// =============================================================================

class UpdateCourt : public QWidget
{
private:

    Box     * caseIDBox;
    QLabel  * infoLabel;
    QLabel  * updateMsg;
    QString   selectedStatus;

    void setMessage(const QString & text, const QString & color)
    {
        updateMsg->setStyleSheet
        (
            MONO + 
            "font-size   : 16px; "
            "font-weight : bold; "
            "color       : " + color + "; "
            "background  : transparent;"
        );
        
        updateMsg->setText(text);
    }

    void clearAll()
    {
        caseIDBox->clear();
        infoLabel->clear();
        updateMsg->clear();
        selectedStatus = "";
    }

public:

    explicit UpdateCourt(QWidget * parent = nullptr) 
        : QWidget(parent)
    {
        new Card(20, 0, 1125, 420, this);

        QLabel * title = new QLabel("UPDATE COURT STATUS", this);
        
        title->setGeometry(40, 18, 1100, 28);
        
        title->setStyleSheet
        (
            MONO +
            "font-size   : 18px; "
            "font-weight : bold; "
            "color       : #ffcc44; "
            "background  : transparent;"
        );

        QLabel * divider = new QLabel(this);
        
        divider->setGeometry(40, 52, 1100, 1);
        
        divider->setStyleSheet("background : rgba(255, 200, 0, 0.20);");

        QLabel * idLabel = new QLabel("Case ID — Load to view current status", this);
        
        idLabel->setGeometry(40, 68, 1100, 24);
        
        idLabel->setStyleSheet(courtFieldLabel());

        caseIDBox       = new Box(40, 94, 900, 38, "Enter Case ID", this);
        
        Button * loadBtn = new Button("LOAD", 960, 94, 160, 38, this);

        infoLabel = new QLabel("", this);
        
        infoLabel->setGeometry(40, 142, 1100, 22);
        
        infoLabel->setStyleSheet
        (
            MONO +
            "font-size   : 16px; "
            "font-weight : bold; "
            "color       : #c0dff5; "
            "background  : transparent;"
        );

        QLabel * statusLabel = new QLabel("Select New Court Status", this);
        
        statusLabel->setGeometry(40, 174, 1100, 24);
        
        statusLabel->setStyleSheet(courtFieldLabel());

        QPushButton * ongoingBtn = new QPushButton("ONGOING", this);
        
        ongoingBtn->setGeometry(40, 206, 350, 52);
        
        ongoingBtn->setCursor(Qt::PointingHandCursor);
        
        ongoingBtn->setStyleSheet
        (
            "QPushButton"
            "{"
            "    background    : rgba(0, 8, 24, 0.98); "
            "    color         : #00eaff; "
            "    font-family   : 'Courier New', monospace; "
            "    font-size     : 16px; "
            "    font-weight   : bold; "
            "    border        : 1px solid #00eaff; "
            "    border-radius : 8px; "
            "    text-align    : center; "
            "}"
            "QPushButton:hover { background : #00eaff; color : #000000; }"
        );

        QPushButton * onHoldBtn = new QPushButton("ON HOLD", this);
        
        onHoldBtn->setGeometry(415, 206, 350, 52);
        
        onHoldBtn->setCursor(Qt::PointingHandCursor);
        
        onHoldBtn->setStyleSheet
        (
            "QPushButton"
            "{"
            "    background    : rgba(0, 8, 24, 0.98); "
            "    color         : #ffcc44; "
            "    font-family   : 'Courier New', monospace; "
            "    font-size     : 16px; "
            "    font-weight   : bold; "
            "    border        : 1px solid #ffcc44; "
            "    border-radius : 8px; "
            "    text-align    : center; "
            "}"
            "QPushButton:hover { background : #ffcc44; color : #000000; }"
        );

        QPushButton * verdictBtn = new QPushButton("VERDICT REACHED", this);
        
        verdictBtn->setGeometry(790, 206, 350, 52);
        
        verdictBtn->setCursor(Qt::PointingHandCursor);
        
        verdictBtn->setStyleSheet
        (
            "QPushButton"
            "{"
            "    background    : rgba(0, 8, 24, 0.98); "
            "    color         : #44ff99; "
            "    font-family   : 'Courier New', monospace; "
            "    font-size     : 16px; "
            "    font-weight   : bold; "
            "    border        : 1px solid #44ff99; "
            "    border-radius : 8px; "
            "    text-align    : center; "
            "}"
            "QPushButton:hover { background : #44ff99; color : #000000; }"
        );

        updateMsg = new QLabel("", this);
        
        updateMsg->setGeometry(40, 274, 700, 22);
        
        updateMsg->setStyleSheet
        (
            MONO +
            "font-size   : 16px; "
            "font-weight : bold; "
            "color       : #00eaff; "
            "background  : transparent;"
        );

        Button * saveBtn = new Button("SAVE", 40, 320, 350, 52, this);

        QObject::connect(loadBtn, &QPushButton::clicked, [this]()
        {
            QString id = caseIDBox->text().trimmed();

            if (id.isEmpty())
            {
                setMessage("  Enter a Case ID.", "#ff6666");
                return;
            }

            QStringList p = FileHandler::loadCourtCase(id);

            if (p.isEmpty())
            {
                setMessage("  Court case not found.", "#ff6666");
                return;
            }

            selectedStatus = p.value(3, "Ongoing").trimmed();
            
            infoLabel->setText("  Loaded: " + p.value(1).trimmed() + " — " + p.value(2).trimmed() + "  |  Current: " + selectedStatus);
            
            setMessage("  Case loaded. Select a new status and click SAVE.", "#00eaff");
        });

        QObject::connect(ongoingBtn, &QPushButton::clicked, [this]()
        { 
            selectedStatus = "Ongoing";         
            setMessage("  Status selected: ONGOING", "#00eaff"); 
        });

        QObject::connect(onHoldBtn, &QPushButton::clicked, [this]()
        { 
            selectedStatus = "On Hold";         
            setMessage("  Status selected: ON HOLD", "#ffcc44"); 
        });

        QObject::connect(verdictBtn, &QPushButton::clicked, [this]()
        { 
            selectedStatus = "Verdict Reached"; 
            setMessage("  Status selected: VERDICT REACHED", "#44ff99"); 
        });

        QObject::connect(saveBtn, &QPushButton::clicked, [this]()
        {
            QString id = caseIDBox->text().trimmed();

            if (id.isEmpty())
            { 
                setMessage("  Load a case first.", "#ff6666"); 
                return; 
            }

            if (selectedStatus.isEmpty())
            { 
                setMessage("  Select a status first.", "#ff6666"); 
                return; 
            }

            if (FileHandler::updateCourtStatus(id, selectedStatus))
            {
                FileHandler::appendLog("ADMIN", "Court status updated — Case: " + id + " → " + selectedStatus);
                
                setMessage("  Status updated to '" + selectedStatus + "' for case " + id + ".", "#44ff99");
                
                clearAll();
            }
            else
            {
                setMessage("  Failed to update. Case not found.", "#ff6666");
            }
        });
    }

    void activate() 
    { 
        clearAll(); 
    }
};

// =============================================================================
//  ADD COURT PANEL
// =============================================================================

class AddCourt : public QWidget
{
private:

    Box    * caseIDBox;
    Box    * accusedBox;
    Box    * crimeBox;
    QLabel * feedback;

    void setFeedback(const QString & text, const QString & color)
    {
        feedback->setStyleSheet
        (
            MONO +
            "font-size   : 16px; "
            "font-weight : bold; "
            "color       : " + color + "; "
            "background  : transparent;"
        );
        
        feedback->setText(text);
    }

    void clearAll()
    {
        caseIDBox->clear();
        accusedBox->clear();
        crimeBox->clear();
        feedback->clear();
    }

public:

    explicit AddCourt(QWidget * parent = nullptr) 
        : QWidget(parent)
    {
        new Card(0, 0, 1125, 440, this);

        QLabel * heading = new QLabel("ADD COURT PROCEEDING", this);
        
        heading->setGeometry(20, 18, 1100, 28);
        
        heading->setStyleSheet
        (
            MONO +
            "font-size   : 18px; "
            "font-weight : bold; "
            "color       : #00eaff; "
            "background  : transparent;"
        );

        QLabel * divider = new QLabel(this);
        
        divider->setGeometry(20, 52, 1100, 1);
        
        divider->setStyleSheet("background : rgba(0, 200, 255, 0.20);");

        QLabel * idLabel = new QLabel("Case ID  *", this);
        
        idLabel->setGeometry(20, 68, 300, 24);
        
        idLabel->setStyleSheet(courtFieldLabel());

        caseIDBox = new Box(20, 94, 1100, 38, "Enter Case ID", this);

        QLabel * accusedLabel = new QLabel("Accused Name  *", this);
        
        accusedLabel->setGeometry(20, 150, 300, 24);
        
        accusedLabel->setStyleSheet(courtFieldLabel());

        accusedBox = new Box(20, 176, 1100, 38, "Enter Accused Name", this);

        QLabel * crimeLabel = new QLabel("Crime Type  *", this);
        
        crimeLabel->setGeometry(20, 232, 300, 24);
        
        crimeLabel->setStyleSheet(courtFieldLabel());

        crimeBox = new Box(20, 258, 1100, 38, "Enter Crime Type", this);

        QLabel * note = new QLabel("  Initial status will be set to 'Ongoing' automatically.", this);
        
        note->setGeometry(20, 314, 720, 22);
        
        note->setStyleSheet(MONO + "font-size : 16px; font-weight : bold; color : #ffcc44; background : transparent;");

        feedback = new QLabel("", this);
        
        feedback->setGeometry(20, 344, 720, 22);
        
        feedback->setStyleSheet(MONO + "font-size : 16px; font-weight : bold; color : #00eaff; background : transparent;");

        Button * saveBtn = new Button("SAVE", 20, 376, 200, 44, this);
        
        ClearButton * clearBtn = new ClearButton("CLEAR", 985, 376, 120, 44, this);

        QObject::connect(clearBtn, &QPushButton::clicked, [this]() 
        { 
            clearAll(); 
        });

        QObject::connect(saveBtn, &QPushButton::clicked, [this]()
        {
            QString id      = caseIDBox->text().trimmed();
            QString accused = accusedBox->text().trimmed();
            QString crime   = crimeBox->text().trimmed();

            if (id.isEmpty() || accused.isEmpty() || crime.isEmpty())
            {
                setFeedback("  All fields are required.", "#ff6666");
                return;
            }

            if (FileHandler::courtCaseExists(id))
            {
                setFeedback("  A court case with this ID already exists.", "#ff6666");
                return;
            }

            FileHandler::saveCourt(id, accused, crime);
            
            FileHandler::appendLog("ADMIN", "Court proceeding added — Case: " + id + "  Accused: " + accused);
            
            setFeedback("  Court proceeding saved successfully!", "#44ff99");
            
            clearAll();
        });
    }

    void activate() 
    { 
        clearAll(); 
    }
};

// =============================================================================
//  COURT PROCEEDINGS PAGE
// =============================================================================

class CourtProceedings : public QWidget
{
private:

    QLabel      * backgroundImg;
    StatCard    * ongoingNumber;
    StatCard    * onHoldNumber;
    StatCard    * verdictNumber;

    Button      * btnView;
    Button      * btnFilter;
    Button      * btnUpdate;
    Button      * btnAdd;
    ViewCourt   * panelView;
    FilterCourt * panelFilter;
    UpdateCourt * panelUpdate;
    AddCourt    * panelAdd;
    int           currentPanel = -1;

    void refreshCounts()
    {
        ongoingNumber->setValue(FileHandler::countCourtByStatus("Ongoing"));
        onHoldNumber->setValue(FileHandler::countCourtByStatus("On Hold"));
        verdictNumber->setValue(FileHandler::countCourtByStatus("Verdict Reached"));
    }

    void showPanel(int index)
    {
        if (index == currentPanel)
        {
            return;
        }

        currentPanel = index;

        panelView  ->setVisible(index == 0);
        panelFilter->setVisible(index == 1);
        panelUpdate->setVisible(index == 2);
        panelAdd   ->setVisible(index == 3);

        refreshCounts();

        switch (index)
        {
            case 0: panelView  ->activate(); break;
            case 1: panelFilter->activate(); break;
            case 2: panelUpdate->activate(); break;
            case 3: panelAdd   ->activate(); break;
            default: break;
        }
    }

public:

    explicit CourtProceedings(bool isAdmin) 
        : QWidget(nullptr)
    {
        setWindowTitle("Court Proceedings — CRIME RECORD MANAGEMENT SYSTEM");

        backgroundImg = UI::setupBackground(this, "backgroundThree.png");
        new Card(0, 0, 320, 900, this);

        QLabel * title = new QLabel("CRIME RECORD\nMANAGEMENT\nSYSTEM", this);
        title->setGeometry(10, 10, 300, 120);
        title->setAlignment(Qt::AlignCenter);
        title->setWordWrap(true);
        title->setStyleSheet(MONO + "font-size:20px; font-weight:bold; letter-spacing:1px; color:#00eaff; background:transparent;");

        QLabel * divOne = new QLabel(this);
        divOne->setGeometry(30, 100, 260, 1);
        divOne->setStyleSheet("background : rgba(0, 200, 255, 0.30);");

        QLabel * tag = new QLabel("[ COURT  SERVICES ]", this);
        tag->setGeometry(0, 110, 320, 30);
        tag->setAlignment(Qt::AlignCenter);
        tag->setStyleSheet(MONO + "font-size:18px; letter-spacing:4px; color:#ffcc44; font-weight:bold; background:transparent;");

        auto makeLegend = [this](const QString & text, const QString & color, int y)
        {
            QLabel * legend = new QLabel(text, this);
            legend->setGeometry(30, y, 270, 24);
            legend->setStyleSheet(MONO + QString("font-size:16px; letter-spacing:4px; font-weight:bold; color:%1; background:transparent;").arg(color));
        };

        makeLegend("ONGOING",         "#00eaff", 172);
        makeLegend("ON HOLD",         "#ffcc44", 200);
        makeLegend("VERDICT REACHED", "#44ff99", 228);

        QLabel * divTwo = new QLabel(this);
        divTwo->setGeometry(30, 264, 260, 1);
        divTwo->setStyleSheet("background : rgba(0, 200, 255, 0.20);");

        ongoingNumber  = new StatCard(380,  140, "#00eaff", "ONGOING",         this);
        onHoldNumber   = new StatCard(850,  140, "#ffcc44", "ON HOLD",         this);
        verdictNumber  = new StatCard(1300, 140, "#44ff99", "VERDICT REACHED", this);

        btnView = new Button("VIEW ALL", 25, 300, 270, 40, this);

        btnFilter = new Button("FILTER BY STATUS", 25, 360, 270, 40, this);

        btnUpdate = nullptr;
        btnAdd    = nullptr;

        if (isAdmin)
        {
            btnUpdate = new Button("UPDATE STATUS", 25, 420, 270, 40, this);

            btnAdd = new Button("ADD RECORD", 25, 480, 270, 40, this);
        }

        BackButton *bb = new BackButton(25, isAdmin ? 540 : 420, 270, 44, this);
        bb->raise();

        QObject::connect(bb, &QPushButton::clicked, [this]() { this->close(); });

        QLabel * pageTitle = new QLabel("COURT PROCEEDINGS", this);
        
        pageTitle->setGeometry(380, 40, 1180, 50);
        
        pageTitle->setStyleSheet
        (
            MONO + 
            "font-size      : 36px; "
            "font-weight    : 900; "
            "letter-spacing : 6px; "
            "color          : #ffffff; "
            "background     : transparent;"
        );

        QLabel * pageSub = new QLabel("Track and update the legal progress of all crime cases", this);
        
        pageSub->setGeometry(380, 95, 1180, 22);
        
        pageSub->setStyleSheet
        (
            MONO + 
            "font-size   : 18px; "
            "font-weight : bold; "
            "color       : #7ab8e0; "
            "background  : transparent;"
        );

        ongoingNumber = new StatCard(380,  140, "#00eaff", "ONGOING",         this);
        onHoldNumber  = new StatCard(850,  140, "#ffcc44", "ON HOLD",         this);
        verdictNumber = new StatCard(1300, 140, "#44ff99", "VERDICT REACHED", this);

        QLabel * footer = new QLabel("DEPARTMENT OF CRIMINAL JUSTICE    |    INTERNAL USE ONLY", this);
        
        footer->setGeometry(0, 872, 1600, 18);
        footer->setAlignment(Qt::AlignCenter);
        
        footer->setStyleSheet
        (
            MONO + 
            "font-size      : 10px; "
            "letter-spacing : 4px; "
            "color          : #7ab8e0; "
            "background     : transparent; "
            "font-weight    : bold;"
        );

        panelView   = new ViewCourt(this);
        
        panelView->setGeometry(380, 240, 1180, 600);
        panelView->hide();

        panelFilter = new FilterCourt(this);
        
        panelFilter->setGeometry(380, 240, 1180, 600);
        panelFilter->hide();

        panelUpdate = new UpdateCourt(this);
        
        panelUpdate->setGeometry(380, 240, 1180, 600);
        panelUpdate->hide();

        panelAdd    = new AddCourt(this);
        
        panelAdd->setGeometry(380, 240, 1180, 600);
        panelAdd->hide();

        QObject::connect(btnView, &QPushButton::clicked, [this]() 
        { 
            showPanel(0); 
        });

        QObject::connect(btnFilter, &QPushButton::clicked, [this]() 
        { 
            showPanel(1); 
        });

        if (isAdmin)
        {
            QObject::connect(btnUpdate, &QPushButton::clicked, [this]() 
            { 
                showPanel(2); 
            });

            QObject::connect(btnAdd, &QPushButton::clicked, [this]() 
            { 
                showPanel(3); 
            });
        }

        showPanel(0);
    }

    void resizeEvent(QResizeEvent *) override
    {
        backgroundImg->setGeometry(0, 0, width(), height());
    }
};

#endif // COURT_H